package org.traccar.protocol;

import org.junit.jupiter.api.Test;
import org.traccar.ProtocolTest;
import org.traccar.model.Position;

public class TrvProtocolDecoderTest extends ProtocolTest {

    @Test
    public void testDecode() throws Exception {

        var decoder = inject(new TrvProtocolDecoder(null));

        verifyDecode(decoder, text(
                "IWAP00355932600077007,8901240204123656505f,310240202365650#"));

        verifyDecode(decoder, text(
                "TRVAP00352121088015548"));

        verifyDecode(decoder, text(
                "IWAPXL,080835"));

        verifyDecode(decoder, text(
                "IWAP10080524A2232.9806N11404.9355E000.1061830323.8706000908000502,460,0,9520,3671,01,zhcn,00,HOME|74-DE-2B-44-88-8C|97&HOME1|74-DE-2B-44-88-8C|97&HOME2|74-DE-2B-44-88-8C|97&HOME3|74-DE-2B-44-88-8C|97"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_SOS));

        verifyDecode(decoder, text(
                "IWAP49,68"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_HEART_RATE, 68));

        verifyDecode(decoder, text(
                "IWAPHT,60,130,85"),
                position(Checks.ATTRIBUTES).attribute("pressureDiastolic", 85));

        verifyDecode(decoder, text(
                "IWAPHP,60,130,85,95,90,36.5,,,,,,,"),
                position(Checks.ATTRIBUTES).attribute("temperature", 36.5));

        verifyDecode(decoder, text(
                "IWAP50,36.7,90"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_BATTERY_LEVEL, 90));

        verifyDecode(decoder, text(
                "IWAP03,06000908000102,5555,30"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_STEPS, 5555));

        verifyDecode(decoder, text(
                "TRVYP14080524A2232.9806N11404.9355E000.1061830323.870600090800010200011,460,0,9520,3671,Home|74-DE-2B-44-88-8C|97&Home1|74-DE-2B-44-88-8C|97&Home2|74-DE-2B-44-88-8C|97& Home3|74-DE-2B-44-88-8C|97"),
                position());

        verifyDecode(decoder, text(
                "TRVYP03190805A1828.9242N07353.9423E000.0150716029.0010000810020201112,404,27,184,10229"),
                position());

        verifyDecode(decoder, text(
                "IWAP02,zh_cn,0,6,260,1,11002|39252|9,11002|35112|23,11002|11043|24,11002|39253|24,11002|13751|24,11018|8102|26,3,a|c0-4a-00-b6-9c-f5|64&a|c0-4a-00-b6-9c-f5|64&a|18-a6-f7-92-35-da|84"),
                position(Checks.NONE));

        verifyDecode(decoder, text(
                "TRVAP01170905A5227.1382N00541.4256E001.7095844000.0008100610020100,204,8,3230,13007"),
                position());

        verifyDecode(decoder, text(
                "TRVCP01,07800010010000602001206001120124"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, text(
                "IWAP00353456789012345"));

        verifyDecode(decoder, text(
                "IWAP01080524A2232.9806N11404.9355E000.1061830323.8706000908000102,460,0,9520,3671,Home|74-DE-2B-44-88-8C|97& Home1|74-DE-2B-44-88-8C|97&Home2|74-DE-2B-44-88-8C|97& Home3|74-DE-2B-44-88-8C|97"),
                position());

        verifyDecode(decoder, text(
                "IWAP02,zh_cn,0,7,460,0,9520|3671|13,9520|3672|12,9520|3673|11,9520|3674|10,9520|3675|9,9520|3676|8,9520|3677|7,4,1|D8-24-BD-79-FA-1F|59&2|3C-46-D8-6D-CE-01|81&3|0C-4C-39-1A-7C-65|69&4|70-A8-E3-5D-D7-C0|65"),
                position(Checks.NONE));

        verifyDecode(decoder, text(
                "IWAP10080524A2232.9806N11404.9355E000.1061830323.8706000908000502,460,0,9520,3671,00,zh-cn,00,HOME|74-DE-2B-44-88-8C|97&HOME1|74-DE-2B-44-88-8C|97&HOME2|74-DE-2B-44-88-8C|97&HOME3|74-DE-2B-44-88-8C|97"),
                position());

        verifyDecode(decoder, text(
                "IWAP03,06000908000102,5555,30"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, text(
                "TRVAP00353456789012345"));

        verifyDecode(decoder, text(
                "TRVCP01,06000908000102"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, text(
                "TRVCP01,100007100000001020151060011"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, text(
                "TRVAP01160211A2544.5118N05553.7586E105.711185941.52010001010010000,424,030,3011,27003"),
                position());

        verifyDecode(decoder, text(
                "TRVAP01160209A2540.8863N05546.6125E005.6075734123.7910000810010000,424,030,3012,27323"),
                position());

        verifyDecode(decoder, text(
                "TRVAP01080524A2232.9806N11404.9355E000.1061830323.8706000908000102,460,0,9520,3671"),
                position());

        verifyDecode(decoder, text(
                "TRVAP01080524A2232.9806N11404.9355E000.1061830323.8706000908000102,460,0,9520,3671"),
                position().location("2008-05-24T06:18:30.000Z", true, 22.54968, 114.08226));

        verifyDecode(decoder, text(
                "TRVAP10080524A2232.9806N11404.9355E000.1061830323.8706000908000502,460,0,9520,3671,00,zh-cn,00"),
                position());

        verifyDecode(decoder, text(
                "TRVYP14220217A5235.7885N00724.1840E000.0130919177.561000050660000200004,262,01,14635,52789,FritzBox7|DC-39-8F-7E-94-73|-89&FritzBox7|24-4E-5D-71-C3-9C|-90&MY_IOT|80-B4-F7-77-9C-7C|-81&MYAP|44-D4-F7-77-9C-7C|-80#"),
                position());

        verifyDecode(decoder, text(
                "IWAP12,080835,+491773329827,+491773329826,+49306618438"));

        verifyDecode(decoder, text(
                "IWAP14,080835,004e0069006b00750054005200410058|+4952032960728,004600720061006e006b|+4952034488,00480061006e00640079|+491725244115,,,,,,,#"));

    }

}
