package org.traccar.protocol;

import org.junit.jupiter.api.Test;
import org.traccar.ProtocolTest;
import org.traccar.model.Position;

public class Gt06ProtocolDecoderTest extends ProtocolTest {

    @Test
    public void testDecode() throws Exception {

        var decoder = inject(new Gt06ProtocolDecoder(null));

        verifyDecode(decoder, binary(
                "787805120099abec0d0a"));

        verifyDecode(decoder, binary(
                "78780D01086471700328358100093F040D0A"));

        verifyDecode(decoder, binary(
                "787813111a0b070d1a310281f7007a0099e015165e3f0d0a"),
                position(Checks.NONE).network(network()
                        .cell(cell().mcc(641).mnc(247).lac(122).cid(39392))));

        verifyDecode(decoder, binary(
                "79790010940a8996802200258125183f0005882f0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ICCID, "8996802200258125183"));

        verifyDecode(decoder, binary(
                "787822281a0b06173b2602e00227db9c553127db9c561a27db9c571627db9ddc0f27dbf5ec0e000000000000020dc80d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787825181a0b07032616026c0200167b1d0f2b3c092b3905524c03000000000000000000018f02350d0a"),
                position(Checks.NONE).network(network()
                        .cell(cell().mcc(620).mnc(2).lac(22).cid(31517))
                        .cell(cell().mcc(620).mnc(2).lac(22).cid(11068))
                        .cell(cell().mcc(620).mnc(2).lac(22).cid(11065))
                        .cell(cell().mcc(620).mnc(2).lac(22).cid(21068))));

        verifyDecode(decoder, binary(
                "787837341a0b070339080000d600030282820000048600a08c0642420a00000000000000000000000000000000000000000000000000000f312b0d0a"),
                position(Checks.NONE).network(network()
                        .cell(cell().mcc(214).mnc(3).lac(33410).cid(1158))
                        .cell(cell().mcc(214).mnc(3).lac(41100).cid(105005578))));

        verifyDecode(decoder, binary(
                "78782417025b1ea412004f312b32313335363337363334323200000000000000000002002ec1490d0a"));

        verifyDecode(decoder, binary(
                "79790011941501282c533a12230ed309f63c8408720d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.PREFIX_TEMP + 1, 25.5));

        verifyDecode(decoder, binary(
                "79790026f16318c0000001010100020101000301000004010100050201950006010010000100008021af0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_POWER, 4.05));

        verifyDecode(decoder, binary(
                "78782da41a0509160203cf05be31f80c306530001c0010012ed000007ef40000000006428b074205041302ff0009389c0d0a"),
                position(Checks.NONE).attribute(Position.KEY_ALARM, Position.ALARM_TAMPERING));

        verifyDecode(decoder, binary(
                "78782e610869412070143950190a1e0d3806c802b0eb0f0561ecdc00d80002d404000004215f0e000001395581000d1ca60d0a"),
                position(Checks.NONE).attribute(Position.KEY_DRIVER_UNIQUE_ID, "20534657"));

        verifyDecode(decoder, binary(
                "7979001f70002c00046919c641007f000ec4a82841074a7fff64012201dc071ea430360d0a"),
                position(Checks.ATTRIBUTES).attribute("tag1Temp", 29.0));

        verifyDecode(decoder, binary(
                "79790008940b02e3048614200d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_POWER, 7.39));

        verifyDecode(decoder, binary(
                "7979003e3819050e0e0c26c5010fd98e0905f53000ccab0e000302c80100000c240000000000048b08001b002e04000015c4003b020000003c0401020001021f60220d0a"),
                position());

        verifyDecode(decoder, binary(
                "78780ca346000106640c01123d5f5e0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "787818a300000005321e020000000002584f000100060000008f920d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_STEPS, 600L));

        verifyDecode(decoder, binary(
                "7979000e941e000000d5000002ee00f59b850d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_HUMIDITY, 75.0));

        verifyDecode(decoder, binary(
                "78789795ffff01180b0d031406da04b5ab0d08813df01ca9002c008a9200004556454e545f3836323739383035323432393038375f30303030303030305f323032345f31315f31325f32325f32305f30365f495f35362e6d70342c4556454e545f3836323739383035323432393038375f30303030303030305f323032345f31315f31325f32325f32305f30365f465f35352e6d70340037d45b0d0a"),
                position().attribute("eventFiles", "EVENT_862798052429087_00000000_2024_11_12_22_20_06_I_56.mp4,EVENT_862798052429087_00000000_2024_11_12_22_20_06_F_55.mp4"));

        verifyDecode(decoder, binary(
                "787840a2180b0f0f3407cf00602cd208354064001c6a02dc650000698100000000095674c9114100002a04000100004b31000000000863829079286793020001a22a8f0d0a"),
                position());

        verifyDecode(decoder, binary(
                "787895a2180b0f0f1d2602dc65000069810000000009569e9648000069810000000009569e3255000069810000000009569e0052000069810000000009569ec846000069810000000009569e64320000000000000000000000000000000000000000000000000000ff06f27cf64f17e13c909a4a53778c3dc83a350fa1b84522976d5ea4854854af976b9ab04cb04e26d703925102a1ce550d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "79790016f26718e430000c0a470000000010020000000024bff50d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "79790037f26718e389000b0a0423027aca200c465a60000a001d01c4a82828ccfe0000024254425554544f4e2c412c53233136382c35340016a1eb0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "7878131340b2fa000201040000000000011c00400e550d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.PREFIX_TEMP + 1, 28.4));

        verifyDecode(decoder, binary(
                "787817360005040002003201010018020192006a015f0324aeaf0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_BATTERY, 4.02));

        verifyDecode(decoder, binary(
                "787840a218061b0e0f05cf021d22430aa2660b005c00014e140000026500000000024d4e02114504df06031c010007d00000000000086973105524576500c802a86fda0d0a"),
                position());

        verifyDecode(decoder, binary(
                "79790007940B010A0B5ACE0D0A"),
                position(Checks.ATTRIBUTES).attribute("networkTechnology", "4G"));

        verifyDecode(decoder, binary(
                "7878293218061301261ccd0274c4ad050d7c960018000a02d4000ac3c70dbdc40b46f004210202af001784290d0a"),
                position(Checks.NONE).altitude(-31703.0));

        verifyDecode(decoder, binary(
                "78782a31180613012b39cc0274c4dc050d7cd000180002d4000ac3c70dbdc4150100000000000002a6000ea40b0d0a"),
                position(Checks.NONE).altitude(678.0));

        verifyDecode(decoder, binary(
                "7878281718060e021831c6026e8acc0c361b1000140001cc00286d000f4dbf0000012ca7e001000004b2630d0a"),
                position().attribute(Position.KEY_DRIVER_UNIQUE_ID, "bf0000012ca7e001"));

        verifyDecode(decoder, binary(
                "78782732180214123324ca0162bdf0041f45d900190b0a02d4000bc5270000ec025206040202005e07e10d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78782616170A080C0E24C0027C58AD0C2B8B0100454E0901CC0025030328E7A0005D4B13021EC373170D0A"),
                position().attribute(Position.KEY_BATTERY_LEVEL, 93));

        verifyDecode(decoder, binary(
                "787826161709130f3a2dcc02c55f2a089f9af9005c210901360481fe066d9b03413e420102035f92fe0d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_SOS));

        verifyDecode(decoder, binary(
                "78782f221709130f3a32cc02c55f2a089f9afc005c2101360481fe066d9b03000000000025d4000000000020002d036049d70d0a"),
                position().attribute(Position.PREFIX_TEMP + 1, 0.32));

        verifyDecode(decoder, binary(
                "78785995ffff01170719152013df0163d45f041ee52018be002f00876900004556454e545f3836323739383035303137353131325f30303030303030305f323032335f30375f32355f31385f33325f30355f31342e6d70340119d15a0d0a"),
                position().attribute(Position.KEY_EVENT, 0x69));

        verifyDecode(decoder, binary(
                "787829a01707150f2d0ecd01635100041e96d000087c02d4020000912e000000000718798d000e0006ed3ce50d0a"),
                position().attribute(Position.KEY_IGNITION, false));

        verifyDecode(decoder, binary(
                "787829a0170704112226cf0163fe7c0420f6f000091302d402000091290000000007186b8f01030001460d010d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "797900109b0344373532304136320d0a000f87f00d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_RESULT, "D7520A62"));

        verifyDecode(decoder, binary(
                "7878241617070a150e24ca01fba0040780e177005c0001720253360027db6204e40400004bf1e90d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_SOS));

        verifyDecode(decoder, binary(
                "78780a130604ea04000006bc8a0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_POWER, null));

        verifyDecode(decoder, binary(
                "797900849404414c4d313d43353b414c4d323d43433b414c4d333d35433b535441313d43303b4459443d30313b534f533d303133323838333730302c2c3b43454e5445523d303133323838333730303b46454e43453d46656e63652c4f46462c302c302e3030303030302c302e3030303030302c3330302c494e206f72204f55542c313b00b79d120d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78782912170316053b3bcf015b51220af1201105d56100000000000000000000869c0130010000000238d1af0d0a"),
                position(Checks.NONE).attribute(Position.KEY_DRIVING_TIME, 0));

        verifyDecode(decoder, binary(
                "78781219012ed042cc00954d00040419000056fe290d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ALARM, Position.ALARM_LOW_BATTERY));

        verifyDecode(decoder, binary(
                "78782DA4150817073B10CF032EEA9C0B6CE0800015141001CC0100009A00000000000A6F24014605041900FF01908A640D0A"),
                position(Checks.NONE).attribute(Position.KEY_ALARM, Position.ALARM_LOW_BATTERY));

        verifyDecode(decoder, binary(
                "78782627100419092D07C5027AC91C0C4658000005370900000000000000008002001900FF00004DF60D0A"),
                position(Checks.NONE).attribute(Position.KEY_ALARM, Position.ALARM_LOW_BATTERY));

        verifyDecode(decoder, binary(
                "78781511170103100e1f9904efe30400a97f88003410ffdd000d0a"),
                position());

        verifyDecode(decoder, binary(
                "787819a5012ed0000075df000000000098661502050413000019a12b0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ALARM, Position.ALARM_TAMPERING));

        verifyDecode(decoder, binary(
                "7878131302801900002e42016f000000003a0177ef180d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_POWER, 3.67));

        verifyDecode(decoder, binary(
                "78782526160913063918c002780fab0c44750f00040008027f14084c0038420600030c020007398e0d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_TAMPERING));

        verifyDecode(decoder, binary(
                "7979000d940516090908081c030defbd2d0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_DOOR, true));

        verifyDecode(decoder, binary(
                "78782516160908063736c0006e70110442fc800000000800000000000000000300002512000473fb0d0a"),
                position(Checks.NONE).attribute(Position.KEY_ALARM, Position.ALARM_TAMPERING));

        verifyDecode(decoder, binary(
                "78782e2416061a103600c80275298404a0a24000184602d4023a49006f060104ed01940000086508004139765000be7d640d0a"),
                position());

        verifyDecode(decoder, binary(
                "79790019941b524649443a3030384642324245424133390d0a000c14930d0a"),
                position(Checks.ATTRIBUTES).attribute("serial", "RFID:008FB2BEBA39"));

        verifyDecode(decoder, binary(
                "7878241216040e102c22cf00915ffb04c6016300195a02d402283b00753f400571040001dda4880d0a"),
                position().attribute(Position.KEY_IGNITION, false));

        verifyDecode(decoder, binary(
                "787831241603060c231e000194620213ee00606a3413ee0060692e000000000000000000000000000000000000000000003a0cb70d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78783B2810010D02020201CC00287D001F713E287D001F7231287D001E232D287D001F4018000000000000000000000000000000000000FF00020005B14B0D0A"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78782111150b0b022c30c804b7af7808810cb0003c00012e02d075df0084890c000679950d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "797900377000000001020035000103002c0004616219d00043000b013601048153931500001a0001000808652820400643521000000101004e46760d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7878171915061810051a01f90101700d08c8f50c0000065494ae0d0a"));

        verifyDecode(decoder, binary(
                "78783B2E10010D02020201CC00287D001F713E287D001F7231287D001E232D287D001F4018000000000000000000000000000000000000FF00020005B14B0D0A"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787822220F0C1D023305C9027AC8180C46586000140001CC00287D001F71000001000820860D0A"),
                position());

        verifyDecode(decoder, binary(
                "78782b1215050d03041bcf031ff30a0be795bc001c17014e14a065dd95314504b6040000001c00000cd90ab8fb6f0d0a"),
                position().attribute(Position.PREFIX_TEMP + 1, 0x1c));

        verifyDecode(decoder, binary(
                "7878151330802b00000642014f0008720000802b5ee4d4c90d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_BATTERY_LEVEL, 6));

        verifyDecode(decoder, binary(
                "7878281520000000003c49434349443a38393838323339303030303039373330323635303e00020d446f260d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ICCID, "89882390000097302650"));

        verifyDecode(decoder, binary(
                "797900099b0380d600046f91e90d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_RESULT, "80d600"));

        verifyDecode(decoder, binary(
                "797900a56615010d081f3b012c323131303d30303033643238342c323130353d30303030316332302c323130623d30303030326537632c323130633d30303033643238342c323130663d30303030306331632c323130643d30303030323166632c323161363d30303030303030302c323130343d30303030306531302c323132663d30303030303030302c323134353d30303030303030302ccb03851f5f03c020525514a7003e216a0d0a"));

        verifyDecode(decoder, binary(
                "797900cd8c15010d08200d013137333d302c3232333d312c3238333d30303032373464382c3436333d30303030303239352c3437333d30303030363333622c3438333d30303030303036372c3242333d30303030303030302c3244333d30303030316332302c3335333d30303030323133342c3336333d30303033626430382c3339333d30303030303336622c3330333d30303030303539362c3439333d30303030306563382c3441333d2c3341333d30303030303430352c3530333d30303030cb03850c3603c025af5414a6003fc5940d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787844F3140C0B0A262A070000DC9FDB1C1D760000C83A3569A37100008825937287000000EC41180C8209000088C39749553700003891D5604D6300003891D5604D68002EC4230D0A"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7979000E9B0332382E33A1E60D0A0289BE490D0A"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_RESULT, "32382e33a1e60d0a"));

        verifyDecode(decoder, binary(
                "7878353714080d05000ac500a886eb0b7522f000100001fe0a05ea004f1b000001002e0400002328003b0217c0003c0401020001002c468a0d0a"),
                position());

        verifyDecode(decoder, binary(
                "79790020940a035985708236675805200502187214018966051912408052452f000355560d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ICCID, "8966051912408052452"));

        verifyDecode(decoder, binary(
                "7878252612030C063816C3026C10540C38C9700144030901CC002866000EEE0C06040302000DA2DB0D0A"),
                position());

        verifyDecode(decoder, binary(
                "78784A1614051C150204EC02777E560C2A2A2A5314AF000000000000040000000000000000000000000000000000000000000000000000000000000000000000000000007E061B0982004B24C00D0A"),
                position().attribute(Position.KEY_BATTERY_LEVEL, 100));

        verifyDecode(decoder, binary(
                "7979000e941b02084277efef350303eadaed0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_DRIVER_UNIQUE_ID, "4277efef"));

        verifyDecode(decoder, binary(
                "7878711213081f081d0fc6017ba3fa0ac62a923e550e02080503f300b26d000000004b20202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202020202030300017c7470d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "797900B2700000000102003500010400330012000000000000000000000000000000000000003400061354A48DFF00003400061154A48E56000011000A000000000000000000000001000803537601000282180002000802140743044211890003000A89340752000038689636001800020182002B000116002C000454A4FF350009000100000A0001010028000100002E000400000000002A00010000290004000000000030000A000101680014016802D00000B38F0D0A"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78780c95130a071223200100013ad10d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ALARM, Position.ALARM_GENERAL));

        verifyDecode(decoder, binary(
                "78783c3400000000130a1906011105029b4d450b1828d5001c00000000009e7d014e140fc000004e990000000004c301a442210000020101c001c0000591aa0d"),
                position().attribute(Position.PREFIX_ADC + 1, 4.48));

        verifyDecode(decoder, binary(
                "797900a87000000001020035000101003300125d7e3a180600d504b598f708814b3a001d1500340006125d7e39dc000011000a012e02620000000000000001000803537601000129800002000803102608593397620003000a89012608522933976266001800020172002b000114002c00045d7df3c70009000106000a000109002800010d002e00040000f25d002a000111002900040000017e0030000a000100b4000a00b402d0000591250d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_REMOVING));

        verifyDecode(decoder, binary(
                "797900a87000000001020035000100003300125d62bf3a0800e804b5994308814a87001d5d00340006115d62bf29000011000a012e02620000000000000001000803537601000129800002000803102608593397620003000a8901260852293397626600180002017d002b000116002c00045d6278ea0009000108000a00010b002800010b002e00040000f0c1002a00010000290004000000be0030000a000100b4000a00b402d00006c5490d0a"),
                position());

        verifyDecode(decoder, binary(
                "797900149b03023539303042343843454238410300139ba40d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_RESULT, "0235393030423438434542384103"));

        verifyDecode(decoder, binary(
                "787821121303120b2524c70138e363085b549003d43301940057d200cd52c000006aa1ca0d0a"),
                position());

        verifyDecode(decoder, binary(
                "7878251613020C12141AC5027951430C2A16F60014000900000000001A00007C550300020002F1E70D0A"),
                position(Checks.NONE).attribute(Position.KEY_ALARM, Position.ALARM_REMOVING));

        verifyDecode(decoder, binary(
                "7878006919012105090303028f01007549e05a00bc9c5c5a007a8d1a5a0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7878001719011910543607028f0100bc2e695a00bcb3635a00bc27c56400bc447b6400bc46c96400bc33ce6400bc64ca640d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "797900de8c120b1502121b013137333d302c3232333d312c3238333d30303030303030302c3436333d30303030303035362c3437333d30303030303030662c3438333d30303030303031312c3242333d30303030303030302c3244333d30303030313839632c3335333d30303030313661382c3336333d30303032386163382c3339333d30303030303230612c3330333d30303030303561612c3439333d30303030303030302c3441333d4b4e4146323431434d4b353031343235352c3341333d30303030303338352c3530333d30303030c0041df0940f89c06700000000c800910d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "79790020940A035985708053908307060104900402788950301217070401538F0003E8210D0A"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78783c3439000000120a0902093a07031f9e690529be2e00155500000016214901a30308b70000b3fb004aa82b059401a3422100000001000000007d9370b90d0a"),
                position());

        verifyDecode(decoder, binary(
                "7878079404eb001c705d0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78781219028f0a29e10036f12003040102000875dc0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "79790008940000ed0289d6860d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "797900a59404414c4d313d34353b414c4d323d44353b414c4d333d35353b535441313d34303b4459443d30313b534f533d303538353036313536372c2c3b43454e5445523d3b46454e43453d46656e63652c4f46462c302c302e3030303030302c302e3030303030302c3330302c494e206f72204f55542c303b49434349443d38393937313033313031303038393539303432463b4d4f44453d4d4f44452c312c3138303b0008f65e0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78782222120616083817c5050cc8c801a819d600152400e8011dbf003332000000004862500d0a"),
                position());

        verifyDecode(decoder, binary(
                "78780B23C00122040001000818720D0A"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78782EA4110C0C02281BF6026C18720C38D22800149C1181CC00010000260E000000000615F8012C05041102FF001058FD0D0A"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78787aa2110c0e06372c813601040000591200000000009d7c01040000591200000000009d7c01040000591200000000009d7c01040000591200000000009d7c01040000591200000000009d7c01040000591200000000009d7c01040000591200000000009d7c0104ff02001801eb4039d10000000000000004fabeb50d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78782727110c0b0e170f850450059107f461ae001c7e0a81360104cb8a00bef32806030c02ff000316b10d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78782322110c070f1b0270000000000000000000040081360104cb8a00bef3000000000523030d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787880a2110b161010140136040000591200000000009d7c01020000591200000000009d7c01020000591200000000009d7c01020000591200000000009d7c01020000591200000000009d7c01020000591200000000009d7c01020000591200000000009d7c0102ff033c1e04ddc28aa6001801eb4039c90000000000000014db84730d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78782ba701cc000000919100000000090617032b3836313832323038343735363200000000000000000100049fb60d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787819a501cc0000009191000000000906170304050400010005f44d0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78782ca3110b10081336f000000000000000000004003901cc0000009191000000000906170304050400010003e0940d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7878A3A2110B0603201501CC010000254E000000000615F804000000254E000000000615F804000000254E000000000615F804000000254E000000000615F804000000254E000000000615F804000000254E000000000615F804000000254E000000000615F80400FF08F483CD4DF4C0D750BD5F8BC5CECFB0D59DAFB459CDA8574E8424C6CC50BD5F6C7E1CC9B0D59D8AA718C90087363040E0C83496727B4DE4C7002919670D0A"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78786CA1110B0413093801CC01000025FC000000000618C10201000025FC000000000618C10201000025FC000000000618C10201000025FC000000000618C10201000025FC000000000618C10201000025FC000000000618C10201000025FC000000000618C10201FF0002000541D70D0A"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787822220F0C1D023305C9027AC8180C46586000140001CC00287D001F71000001000820860D0A"),
                position());

        verifyDecode(decoder, binary(
                "797900262100000000020043006f006d006d0061006e00640020006500720072006f0072002100236e850d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "787803691604130318491475905BD30E25001E10BBF7635D14759006E626560501CC0028660F213228660F1F2828660EA81E286610731428660F20140D0A"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787800691710231108500200cc080c4e2fa5640c4e2fa66e0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787800171710231108290200cc080c4e2fa5640c4e2fa5640d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787800691710231109200400cc080c4e2fa55a0c4ec0025a0c4e2fa6640c583918640d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787800691710231111210700cc080c4e2fa55a0c4ec0025a0c4e39295a0c583918640c4e2fa6640c4e2fa4640c4ec854640d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787800171710231112510600cc080c4e2fa55a0c4e2fa55a0c4e2fa55a0c4e2fa55a0c4e2fa55a0c4e2fa55a0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7878121011091c0b1b2999058508040097a89e0034520d0a"),
                position());

        verifyDecode(decoder, binary(
                "78780869170928113413ac9e17b30808514494fcf6e148596cb0ce2c67bd4a6eb0ce2c67bd4b0018e7d4333e55ec086be7f2df5fe48d8c94fc6657e48d8cb8f378510600cc0400d37a3d4600d37a3c5000d37a3b6400d376716400d305ac6400d393506e0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787808171709281135331491827b75594dc8d719a9708452cad719a9708550cad719a97086521491827b75574cac9e17b308085dc8d71939633947cad71939633a480700cc0400d37a3d5a00d37a3d5a00d37a3d5a00d37a3d5a00d37a3d5a00d37a3d5a00d37a3d5a0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78783b281108111002050136041bcf0000bf09000000000000000000000000000000000000000000000000000000000000000000000000ff00020007d3280d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7878412c11030b011c1f013604cb8a00b17754cb8a00bef357cb8a00b73f5fcb8900b0e25fcb8900b6655fcb8a00b74960cb8a00b178620701001801eb40393800bbbde10d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7878412c11030b012629013604cb8a00b17757cb8a00b73f5bcb8a00b7495ecb8900b0e25fcb8a00b1b9620000000000ff0000000000ffff01001801eb40393e00c0e6340d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787822221106160a1016c60278019407c7783800040001940504700046fc01030100065f570d0a"),
                position());

        verifyDecode(decoder, binary(
                "797900143311070609020b00000000a0030046000109e4610d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "7979003e32110707083819000901fe0a060f006a1e3f24000000000000000000000000000000000000000000000000000000000000000000000000000000012116ba0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "7979007632110706090217000901fe0a060f006a1c2024060f0053a429060f006a1d21060f0053a720060f006f151d0000000000000000000000003844d9e7f7e1773d60e327a9e442405cf28628b9c640a42bb0fc0d0244d855a38c220a4c802aa8da7dab50b0e235ef32dd5348ee0ce77a52540000010a205a0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "7979006f210000000001426174746572793a352e3536562c4e4f524d414c3b20475052532a4c696e6b2055702047534d205369676e616c204c6576656c3a5374726f6e673b204750533a4f46463b2020204c4f434b3a4f46463b204254204d41433a4234413832383034343436323b007260880d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "7979004a321106170c1b180cc900a875580b7ab4f00010350901fe0a007c0009112424007c000912240081004efe2100c500100f1200000000000000000000000000000000000000000000bc7c900d0a"),
                position());

        verifyDecode(decoder, binary(
                "79790045321106170c1b13000901fe0a007c0009112424007c000912230081004efe1e00c500100f120000000000000000000000000000000000000710bef565574e37000000b26f140d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787811010863586038760942a0010000010aa4000d0a"));

        verifyDecode(decoder, binary(
                "78781f3511061a0b24330503107d06084889cb01000100000cfa20e3acd301333fcb0d0a"));

        verifyDecode(decoder, binary(
                "78783c340000000011061809130c0903107d2408488a5800144c00000000000001940b00b1000047ff000000000500018f42210000000100050003010b69450d0a"),
                position());

        verifyDecode(decoder, binary(
                "78783c34000000001106190336070903107d51084889b900152e0000000043b101940b00b10000480100000000050001a3422100000001000300011bdc7b5f0d0a"),
                position());

        verifyDecode(decoder, binary(
                "78780a13c40604000201298f5b0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78781f12110616091835d0024bb93007d3fb783dd4c501940500f2006c8504a6e0370d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787822221106160a1016c60278019407c7783800040001940504700046fc01030100065f570d0a"),
                position());

        verifyDecode(decoder, binary(
                "7878661500000000004459443d537563636573732100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000010009e82b0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7979000894000000000338ba0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "79790020940a03516080825457290502194200448892980691312079088572f50004d4350d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "7979007121000000000143757272656e7420706f736974696f6e214c61743a4e35342e3733393333322c4c6f6e3a4532352e3237333237302c436f757273653a3132362e35332c53706565643a302e303030302c4461746554696d653a323031372d30352d3236202031303a32373a3437000bbee30d0a"),
                position());

        verifyDecode(decoder, binary(
                "7979003F940D110315102A202141494F494C2C30322C3030382E3239302C3032392E3630302C3531394A2C303430302C3030382E3433302C302C30302C4142001678EA0D0A"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "79790039940d2141494f494c2c30322c3030322e3732302c3032392e3530302c3532344a2c303130302c3030332e3430302c302c30302c393309ad72000d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "79790005840016BB1A0D0A"));

        verifyDecode(decoder, binary(
                "797900089400000002e852d70d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "7979000794050000c9b63e0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78783b18100c0f1201010195271784005ab63617840002fa47178400ff8f4817840019f3491784005ab54b178400ff8e4c17840019f24cff0002012287c80d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "7878251610051b0f1c34c5022515d504b5dcd20738080902d4022bdf009cba5006640201006759680d0a"),
                position());

        verifyDecode(decoder, binary(
                "787866150000000000416c726561647920696e20746865207374617465206f66206675656c20737570706c7920746f20726573756d652c74686520636f6d6d616e64206973206e6f742072756e6e696e672100000000000000000000000000000000000001001981e50d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78782d152500000000437574206f666620746865206675656c20737570706c793a2053756363657373210002013b898a0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "787829152100000000526573746f7265206675656c20737570706c793a2053756363657373210002014077ce0d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78780D01012345678901234500018CDD0D0A"));

        verifyDecode(decoder, binary(
                "78780d0103534190360660610003c3df0d0a"));

        verifyDecode(decoder, binary(
                "78780a13440604000201baaf540d0a"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "787825160F0C1D0A2B21C8027AC8040C46581000146F0901CC00287D001F714804040301001C84CF0D0A"),
                position(Checks.ATTRIBUTES));

        verifyDecode(decoder, binary(
                "78781f120f0a140e150bc505e51e780293a9e800540000f601006e0055da00035f240d0a"),
                position().location("2015-10-20T14:21:11.000Z", true, 54.94535, 24.01762));

        verifyDecode(decoder, binary(
                "787823120f081b121d37cb01c8e2cc08afd3c020d50201940701d600a1190041ee100576d1470d0a"),
                position());

        verifyDecode(decoder, binary(
                "78781F120B081D112E10CC027AC7EB0C46584900148F01CC00287D001FB8000380810D0A"),
                position());

        verifyDecode(decoder, binary(
                "787819100B031A0B1B31CC027AC7FD0C4657BF0115210001001CC6070D0A"),
                position());

        verifyDecode(decoder, binary(
                "787821120C010C0F151FCF027AC8840C4657EC00140001CC00287D001F720001000F53A00D0A"),
                position());

        verifyDecode(decoder, binary(
                "787825160B051B093523CF027AC8360C4657B30014000901CC00266A001E1740050400020008D7B10D0A"),
                position());

        verifyDecode(decoder, binary(
                "787819100e010903230ec803ae32a60653cded00180000020072feb70d0a"),
                position());

        verifyDecode(decoder, binary(
                "7878471e0e03110b0511c501c664fd074db73f0218a602e003433a002fed40433a0056e14e433a0056104e433a0056fd53433a002eed55433a007e4b57433a002ee25aff00020120f6720d0a"),
                position());

        verifyDecode(decoder, binary(
                "7979005bfd0358899050927725004c0020bf984358df603b2ea3a339e54335013a5b56455253494f4e5d47543036445f32305f3630444d325f423235455f5631355f574d5b4255494c445d323031332f31322f32382031353a3234002a3b240d0a7979005bfd0358899050927725004c0020bf984358df603b2ea3a339e54335013a5b56455253494f4e5d47543036445f32305f3630444d325f423235455f5631355f574d5b4255494c445d323031332f31322f32382031353a3234002d4f9b0d0a7979005bfd0358899050927725004c0020bf984358df603b2ea3a339e54335013a5b56455253494f4e5d47543036445f32305f3630444d325f423235455f5631355f574d5b4255494c445d323031332f31322f32382031353a3234003084ff0d0a"));

        verifyDecode(decoder, binary(
                "78788b818300000000534545464e2626004f04220045042626262b37393035343031353534362626262626260410041b0415041a04210415041926262b373930363433333031313526260410043d044f26262b373936303437383430363426260412043e0432043026262b373932383834373738383126262626262626262626262626262626232300020022155d0d0a"));

        verifyDecode(decoder, binary(
                "787822220e0914160f07c9021a362805090a7800d8b802d402c30e00a98a0105010213f4bb0d0a"),
                position());

        verifyDecode(decoder, binary(
                "787811010864717003664467100f190a0002c6d20d0a"));

        verifyDecode(decoder, binary(
                "787811010123456789012345100B3201000171930D0A"));

        verifyDecode(decoder, binary(
                "78780d1f000000000000000200b196a20d0a"));

        verifyDecode(decoder, binary(
                "78781f12110819110216d402f250340828924055d4c801944600d300c09501429c830d0a"),
                position());

        verifyDecode(decoder, binary(
                "78782516110819110208d402f264dc08289a4058d4c70901944600d300c0954606040600014057e90d0a"),
                position());

        verifyDecode(decoder, binary(
                "78780d010359339075005244340d0a"));

        verifyDecode(decoder, binary(
                "787800691709261259400700cc0400d376714600d37a3d5000d37a3c5000d393505a00d3765d5a00d376735a00d32e6b640d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "787801080d0a"));

        verifyDecode(decoder, binary(
                "78782E2A0F0C1D071139CA027AC8000C4658000014D83132353230313335333231373730373900000000000001002A6ECE0D0A"));

        verifyDecode(decoder, binary(
                "7878058A000688290D0A"));

        verifyDecode(decoder, binary(
                "78780c95130a0209321c90000112800d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ALARM, Position.ALARM_ACCELERATION));

        verifyDecode(decoder, binary(
                "78780c95130a0209321c91000112800d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_ALARM, Position.ALARM_BRAKING));

        verifyDecode(decoder, binary(
                "78788b95140a060e2208055D4A800209D9C014c59100004556454e545f3335333337363131303032333139365f30303030303030305f323032305f31305f30365f31365f33345f30385f33322e6d70342c4556454e545f3335333337363131303032333139365f30303030303030305f323032305f31305f30365f31365f33345f30385f33312e6d70340000da360d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_BRAKING));

        verifyDecode(decoder, binary(
                "78788b95140a070c1434055D4A800209D9C014280100004556454e545f3335333337363131303032333139365f30303030303030305f323032305f31305f30375f31345f32305f35325f32342e6d70342c4556454e545f3335333337363131303032333139365f30303030303030305f323032305f31305f30375f31345f32305f35325f32332e6d7034003f6b260d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_SOS));

        verifyDecode(decoder, binary(
                "78785195140a020c2914055D4A800209D9C014009300004556454e545f3335333337363131303032333139365f30303030303030305f323032305f31305f30325f31345f34315f32305f30352e6d70340004e3a60d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_ACCIDENT));

        decoder.setModelOverride("LW4G-4B");

        verifyDecode(decoder, binary(
                "78780a13560604f0830ccf986f0d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_POWER, 13.1));

        verifyDecode(decoder, binary(
                "78782516180516150812c804b50ee80880e40805dcf909012e000000986633460604190106c393490d0a"),
                position(Checks.NONE).attribute(Position.KEY_ALARM, Position.ALARM_ACCELERATION));

        decoder.setModelOverride("SEEWORLD");

        verifyDecode(decoder, binary(
                "78780a134506560b0102242b850d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_POWER, 11.0));

        decoder.setModelOverride("R11");

        verifyDecode(decoder, binary(
                "78780a13460b120400160642c20d0a"),
                position(Checks.ATTRIBUTES).attribute(Position.KEY_POWER, 28.34));

        decoder.setModelOverride("NT20");

        verifyDecode(decoder, binary(
                "78783c22010357789648774484180c06142038180c06142038cb03313ee4061fe98300185e090000000000000000460984284c000200000000017101d6f35d0d0a"),
                position(Checks.NONE).attribute(Position.KEY_HOURS, 22140000L));

        decoder.setModelOverride("XT40");

        verifyDecode(decoder, binary(
                "78783c220109999999999999991a04171433101a041714310fb00288a5a8050754500008000800000000000000000604e32933000200468b000025008d87ce0d0a"),
                position(Checks.NONE).attribute(Position.KEY_POWER, 12.51));

        verifyDecode(decoder, binary(
                "78783c22010357789648774484180c06142038180c06142038cb03313ee4061fe98300185e090000000000000000460984284c000200000000017101d6f35d0d0a"),
                position(Checks.NONE).attribute(Position.KEY_BATTERY, 4.0));

        verifyDecode(decoder, binary(
                "78784e25010356354871186947190909100e0f190909100e0fbf02846fe805078c900018000a02d410c80b0c352c17044605112a4700020000000005840f0102353130303635383036424446030113ed780d0a"),
                position().attribute(Position.KEY_DRIVER_UNIQUE_ID, "0235313030363538303642444603"));

        decoder.setModelOverride("G18");

        verifyDecode(decoder, binary(
                "787825161a011c141001cf00bc62e0043533a231113808028005006800124b470603300204baa49a0d0a"),
                position().attribute(Position.KEY_ALARM, Position.ALARM_BRAKING));

        decoder.setModelOverride("QH302R");

        verifyDecode(decoder, binary(
                "7878271208667030665022971a020c0a1e32c601727c1c0f89af002c14fa01366e000100010c003c1fdd0d0a"),
                position());

        decoder.setModelOverride("VL103");

        verifyDecode(decoder, binary(
                "787822221607160f1000cf0225e03f0bd723182c149701cc0075c300933301000002a5f0860d0a"),
                position());

        verifyDecode(decoder, binary(
                "78782aa015041007350eca027ac8a20c4658be00140081cc00000000287d0000000002ea5e010004000009dffc0d0a"),
                position());

        verifyDecode(decoder, binary(
                "7979007e7000000001020035000100003300126303564e07017004ea01f800f41d5c001466003400060e6303564e000043000b00de00322ae9770600000d0001000808685650500023470002000802225000120407580003000a8939500021051530683600180002019510000001010009000107000a00010c00280001120ce2299a0d0a"),
                position(Checks.NONE));

        verifyDecode(decoder, binary(
                "78783536190c1d0f1724cf026cc9140c367d4000940001cc0025ef0540e88c01000000000064051428000006c3000001453f9201003477560d0a"),
                position());

        verifyDecode(decoder, binary(
                "78783536190c1d0f1724cf026cc9140c367d4000940001cc0025ef0540e88c01000000000064051428000006c3000001453f9201003477560d0a"),
                position().attribute(Position.KEY_DRIVER_UNIQUE_ID, "c3000001453f9201"));

        verifyDecode(decoder, binary(
                "78783536190c1d0f2806cf026cc9140c367d4000540001cc0025ef0540e88c00000000000064051e2800001600000000000000006e5bc2660d0a"),
                position().attribute(Position.KEY_BATTERY, 4.0));

        verifyDecode(decoder, binary(
                "78782d16190c1d0e3b03cf026cc8d40c367d800014000801cc0025ef40e88c450604e801c3000001453f920100271e590d0a"),
                position().attribute(Position.KEY_DRIVER_UNIQUE_ID, "c3000001453f9201"));

        verifyDecode(decoder, binary(
                "78782d16190c1d0f0b07cf026cc89c0c367cf00014000801cc0025ef40e88c460604ea01c3000001453f9201000c103a0d0a"),
                position().attribute(Position.KEY_EVENT, 0xEA));

    }

}
