package org.traccar.protocol;

import org.junit.jupiter.api.Test;
import org.traccar.ProtocolTest;

public class Pt215ProtocolDecoderTest extends ProtocolTest {

    @Test
    public void testDecode() throws Exception {

        var decoder = inject(new Pt215ProtocolDecoder(null));

        verifyDecode(decoder, binary(
                "58580d010359339075435451010d0a"));

        verifyDecode(decoder, binary(
                "585801080d0a"));

    }

}
