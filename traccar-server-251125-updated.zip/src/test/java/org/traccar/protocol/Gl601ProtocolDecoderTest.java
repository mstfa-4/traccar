package org.traccar.protocol;

import org.junit.jupiter.api.Test;
import org.traccar.ProtocolTest;

public class Gl601ProtocolDecoderTest extends ProtocolTest {

    @Test
    public void testDecode() throws Exception {

        var decoder = inject(new Gl601ProtocolDecoder(null));

        verifyDecode(decoder, binary(
                "2b000038000861261070000480c031000a00002167d94c722ca750005216190083b71a02ad58a267d94c7300000501120003a2231f3d3c24"),
                position());

        verifyDecode(decoder, binary(
                "2b000048000861261070000944c031000c000031677e5c900049120052162900ed28bf02b5fcdf677e5c90000c0701610005e211550e0500559609010000314d800212630043d724"),
                position());

        verifyDecode(decoder, binary(
                "2d000027000861261070000944c031000c000010677e5b50004120026105010f404a0000453a24"),
                position(Checks.ATTRIBUTES));

    }

}
