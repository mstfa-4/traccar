package org.traccar.protocol;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.traccar.ProtocolTest;
import org.traccar.model.Command;

public class CellocatorProtocolEncoderTest extends ProtocolTest {

    @Disabled
    @Test
    public void testEncode() throws Exception {

        var channel = channel(inject(new CellocatorProtocolEncoder(null)));

        Command command = new Command();
        command.setDeviceId(1);
        command.setType(Command.TYPE_OUTPUT_CONTROL);
        command.set(Command.KEY_INDEX, 0);
        command.set(Command.KEY_DATA, "1");

        verifyEncode(channel, command,
                binary("4D434750000000000000000000000303101000000000000026"));

    }

}
