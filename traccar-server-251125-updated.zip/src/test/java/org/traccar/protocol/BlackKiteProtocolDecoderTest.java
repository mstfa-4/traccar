package org.traccar.protocol;

import org.junit.jupiter.api.Test;
import org.traccar.ProtocolTest;

public class BlackKiteProtocolDecoderTest extends ProtocolTest {

    @Test
    public void testDecode() throws Exception {

        var decoder = inject(new BlackKiteProtocolDecoder(null));

        verifyDecode(decoder, binary(
                "01150003313131313131313131313131313131209836055605BA"));

        verifyDecode(decoder, binary(
                "0136000331313131313131313131313131313120523905563000010000000100000033000000003400004000004500004600005000005100009F76"),
                position());

    }

}
