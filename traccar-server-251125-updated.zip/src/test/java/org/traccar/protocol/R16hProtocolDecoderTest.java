package org.traccar.protocol;

import org.junit.jupiter.api.Test;
import org.traccar.ProtocolTest;

public class R16hProtocolDecoderTest extends ProtocolTest {

    @Test
    public void testDecode() throws Exception {

        var decoder = inject(new R16hProtocolDecoder(null));

        verifyDecode(decoder, text(
                "@LINK,356823031235028"));

        verifyDecode(decoder, text(
                "@GPSD,356823031235028,R,20260520,000133,01.34587,N,103.71993,E,0,111,36,72,L,"),
                position());

        verifyDecode(decoder, text(
                "@LBSD,356823031235028,R,20260616,092110,302-490-75f8-61c3715:-111,,,21,L,"),
                position(Checks.ATTRIBUTES));

    }

}
