/*
 * Copyright 2015 - 2026 Anton Tananaev (anton@traccar.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.traccar.geocoder;

import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.traccar.database.StatisticsManager;

import jakarta.json.JsonArray;
import jakarta.json.JsonObject;
import jakarta.json.JsonString;
import jakarta.json.JsonValue;
import jakarta.ws.rs.client.Client;
import jakarta.ws.rs.client.InvocationCallback;
import java.util.AbstractMap;
import java.util.Map;

public abstract class JsonGeocoder implements Geocoder {

    private static final Logger LOGGER = LoggerFactory.getLogger(JsonGeocoder.class);

    private final Client client;
    private final String url;
    private final AddressFormat addressFormat;
    private StatisticsManager statisticsManager;

    private Cache<Map.Entry<Double, Double>, String> cache;

    public JsonGeocoder(Client client, String url, final int cacheSize, AddressFormat addressFormat) {
        this.client = client;
        this.url = url;
        this.addressFormat = addressFormat;
        if (cacheSize > 0) {
            this.cache = CacheBuilder.newBuilder().maximumSize(cacheSize).build();
        }
    }

    @Override
    public void setStatisticsManager(StatisticsManager statisticsManager) {
        this.statisticsManager = statisticsManager;
    }

    protected String readValue(JsonObject object, String key) {
        if (object != null && object.containsKey(key) && !object.isNull(key)) {
            JsonValue value = object.get(key);
            if (value.getValueType() == JsonValue.ValueType.STRING) {
                return ((JsonString) value).getString();
            }
        }
        return null;
    }

    protected JsonObject readObject(JsonObject object, String key) {
        if (object != null && object.containsKey(key) && !object.isNull(key)) {
            JsonValue value = object.get(key);
            if (value.getValueType() == JsonValue.ValueType.OBJECT) {
                return (JsonObject) value;
            }
        }
        return null;
    }

    protected JsonArray readArray(JsonObject object, String key) {
        if (object != null && object.containsKey(key) && !object.isNull(key)) {
            JsonValue value = object.get(key);
            if (value.getValueType() == JsonValue.ValueType.ARRAY) {
                return (JsonArray) value;
            }
        }
        return null;
    }

    private String handleResponse(
            double latitude, double longitude, JsonObject json, ReverseGeocoderCallback callback) {

        Address address = parseAddress(json);
        if (address != null) {
            String formattedAddress = addressFormat.format(address);
            if (cache != null) {
                cache.put(new AbstractMap.SimpleImmutableEntry<>(latitude, longitude), formattedAddress);
            }
            if (callback != null) {
                callback.onSuccess(formattedAddress);
            }
            return formattedAddress;
        } else {
            String msg = "Empty address. Error: " + parseError(json);
            if (callback != null) {
                callback.onFailure(new IllegalStateException(msg));
            } else {
                LOGGER.warn(msg);
            }
        }
        return null;
    }

    @Override
    public String getAddress(
            final double latitude, final double longitude, final ReverseGeocoderCallback callback) {

        if (cache != null) {
            String cachedAddress = cache.getIfPresent(new AbstractMap.SimpleImmutableEntry<>(latitude, longitude));
            if (cachedAddress != null) {
                if (callback != null) {
                    callback.onSuccess(cachedAddress);
                }
                return cachedAddress;
            }
        }

        if (statisticsManager != null) {
            statisticsManager.registerGeocoderRequest();
        }

        var request = client.target(String.format(url, latitude, longitude)).request();

        if (callback != null) {
            request.async().get(new InvocationCallback<JsonObject>() {
                @Override
                public void completed(JsonObject json) {
                    handleResponse(latitude, longitude, json, callback);
                }

                @Override
                public void failed(Throwable throwable) {
                    callback.onFailure(throwable);
                }
            });
        } else {
            try {
                return handleResponse(latitude, longitude, request.get(JsonObject.class), null);
            } catch (Exception e) {
                LOGGER.warn("Geocoder network error", e);
            }
        }
        return null;
    }

    public abstract Address parseAddress(JsonObject json);

    protected String parseError(JsonObject json) {
        return null;
    }

}
