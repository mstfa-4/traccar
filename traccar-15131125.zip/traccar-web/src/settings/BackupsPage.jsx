import { useState } from 'react';
import {
  Table,
  TableRow,
  TableCell,
  TableHead,
  TableBody,
  IconButton,
  Tooltip,
  Typography,
} from '@mui/material';
import FileDownloadIcon from '@mui/icons-material/FileDownload';
import { useAsyncTask } from '../reactHelper';
import { formatTime } from '../common/util/formatter';
import { useTranslation } from '../common/components/LocalizationProvider';
import PageLayout from '../common/components/PageLayout';
import SettingsMenu from './components/SettingsMenu';
import TableShimmer from '../common/components/TableShimmer';
import useSettingsStyles from './common/useSettingsStyles';
import fetchOrThrow from '../common/util/fetchOrThrow';

const formatSize = (bytes) => {
  if (bytes >= 1073741824) {
    return `${(bytes / 1073741824).toFixed(2)} GB`;
  }
  if (bytes >= 1048576) {
    return `${(bytes / 1048576).toFixed(2)} MB`;
  }
  if (bytes >= 1024) {
    return `${(bytes / 1024).toFixed(2)} KB`;
  }
  return `${bytes} B`;
};

const BackupsPage = () => {
  const { classes } = useSettingsStyles();
  const t = useTranslation();

  const [items, setItems] = useState(null);

  useAsyncTask(async ({ signal }) => {
    const response = await fetchOrThrow('api/backups', { signal });
    const data = await response.json();
    setItems(data);
  }, []);

  const handleDownload = (name) => {
    window.location.assign(`api/backups/${encodeURIComponent(name)}`);
  };

  return (
    <PageLayout menu={<SettingsMenu />} breadcrumbs={['settingsTitle', 'settingsBackups']}>
      <Table className={classes.table}>
        <TableHead>
          <TableRow>
            <TableCell>{t('backupName')}</TableCell>
            <TableCell>{t('backupSize')}</TableCell>
            <TableCell>{t('backupDate')}</TableCell>
            <TableCell className={classes.columnAction} />
          </TableRow>
        </TableHead>
        <TableBody>
          {!items && <TableShimmer columns={4} />}
          {items && items.length === 0 && (
            <TableRow>
              <TableCell colSpan={4}>
                <Typography variant="body2" color="textSecondary">
                  {t('backupEmpty')}
                </Typography>
              </TableCell>
            </TableRow>
          )}
          {items &&
            items.map((item) => (
              <TableRow key={item.name}>
                <TableCell>{item.name}</TableCell>
                <TableCell>{formatSize(item.size)}</TableCell>
                <TableCell>{formatTime(item.date)}</TableCell>
                <TableCell className={classes.columnAction} padding="none">
                  <Tooltip title={t('backupDownload')}>
                    <IconButton onClick={() => handleDownload(item.name)} size="small">
                      <FileDownloadIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                </TableCell>
              </TableRow>
            ))}
        </TableBody>
      </Table>
    </PageLayout>
  );
};

export default BackupsPage;
