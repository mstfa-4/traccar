import { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button, TextField, Typography, IconButton, InputAdornment } from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import { useNavigate } from 'react-router-dom';
import LoginLayout from './LoginLayout';
import { useTranslation } from '../common/components/LocalizationProvider';
import { useCatch, useAsyncTask } from '../reactHelper';
import { messagesActions, sessionActions } from '../store';
import BackIcon from '../common/components/BackIcon';
import PasswordField from '../common/components/PasswordField';
import TotpQrCodeButton from '../common/components/TotpQrCodeButton';
import fetchOrThrow from '../common/util/fetchOrThrow';

const useStyles = makeStyles()((theme) => ({
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: theme.spacing(2),
  },
  header: {
    display: 'flex',
    alignItems: 'center',
  },
  title: {
    fontSize: theme.spacing(3),
    fontWeight: 500,
    marginLeft: theme.spacing(1),
    textTransform: 'uppercase',
  },
}));

const RegisterPage = () => {
  const { classes } = useStyles();
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const t = useTranslation();

  const server = useSelector((state) => state.session.server);
  const totpForce = useSelector((state) => state.session.server.attributes.totpForce);

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [totpKey, setTotpKey] = useState(null);

  useAsyncTask(
    async ({ signal }) => {
      if (totpForce) {
        const response = await fetchOrThrow('api/users/totp', { method: 'POST', signal });
        setTotpKey(await response.text());
      }
    },
    [totpForce, setTotpKey],
  );

  const handleSubmit = useCatch(async (event) => {
    event.preventDefault();
    setSubmitting(true);
    try {
      await fetchOrThrow('api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, totpKey }),
      });
      dispatch(messagesActions.push({ message: t('loginCreated'), severity: 'success' }));
      dispatch(sessionActions.updateServer({ ...server, newServer: false }));
      navigate('/login');
    } finally {
      setSubmitting(false);
    }
  });

  return (
    <LoginLayout>
      <div className={classes.container}>
        <div className={classes.header}>
          {!server.newServer && (
            <IconButton color="primary" onClick={() => navigate('/login')}>
              <BackIcon />
            </IconButton>
          )}
          <Typography className={classes.title} color="primary">
            {t('loginRegister')}
          </Typography>
        </div>
        <TextField
          required
          label={t('sharedName')}
          name="name"
          value={name}
          autoComplete="name"
          autoFocus
          onChange={(event) => setName(event.target.value)}
        />
        <TextField
          required
          type="email"
          label={t('userEmail')}
          name="email"
          value={email}
          autoComplete="email"
          onChange={(event) => setEmail(event.target.value)}
        />
        <PasswordField
          required
          label={t('userPassword')}
          name="password"
          value={password}
          autoComplete="current-password"
          onChange={(event) => setPassword(event.target.value)}
        />
        {totpForce && (
          <TextField
            required
            label={t('loginTotpKey')}
            name="totpKey"
            value={totpKey || ''}
            slotProps={{
              input: {
                readOnly: true,
                endAdornment: (
                  <InputAdornment position="end">
                    <TotpQrCodeButton email={email} totpKey={totpKey} />
                  </InputAdornment>
                ),
              },
            }}
          />
        )}
        <Button
          variant="contained"
          color="secondary"
          onClick={handleSubmit}
          type="submit"
          disabled={
            submitting ||
            !name ||
            !password ||
            !(server.newServer || /(.+)@(.+)\.(.{2,})/.test(email))
          }
          fullWidth
        >
          {t('loginRegister')}
        </Button>
      </div>
    </LoginLayout>
  );
};

export default RegisterPage;
