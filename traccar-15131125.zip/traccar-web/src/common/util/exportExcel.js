import { saveAs } from 'file-saver';
import { alpha, rgbToHex } from '@mui/material/styles';

const borderDefinition = {
  top: { style: 'thin' },
  left: { style: 'thin' },
  bottom: { style: 'thin' },
  right: { style: 'thin' },
};

const exportExcel = async (title, fileName, sheets, theme) => {
  if (sheets.size === 0) {
    return;
  }

  const { default: ExcelJS } = await import('exceljs');
  const workbook = new ExcelJS.Workbook();
  const headerColor = `FF${rgbToHex(alpha(theme.palette.primary.main, 1)).slice(1, 7).toUpperCase()}`;
  const headerTextColor = `FF${rgbToHex(alpha(theme.palette.primary.contrastText, 1)).slice(1, 7).toUpperCase()}`;

  sheets.forEach((rows, sheetTitle) => {
    const worksheet = workbook.addWorksheet(sheetTitle.replace(/[*?:\\/[\]]|^'|'$/g, ''));
    const headers = Object.keys(rows[0]);

    const titleRow = worksheet.addRow([title]);
    if (headers.length > 1) {
      worksheet.mergeCells(1, 1, 1, headers.length);
    }
    titleRow.font = { bold: true };

    const headerRow = worksheet.addRow(headers);
    headerRow.eachCell((cell) => {
      cell.border = borderDefinition;
      cell.font = { color: { argb: headerTextColor } };
      cell.fill = {
        type: 'pattern',
        pattern: 'solid',
        fgColor: { argb: headerColor },
      };
    });

    rows.forEach((item) => {
      const values = headers.map((header) => item[header]);
      const row = worksheet.addRow(values);
      row.eachCell({ includeEmpty: true }, (cell) => {
        cell.border = borderDefinition;
        cell.font = {};
      });
    });

    headers.forEach((header, index) => {
      let maxLength = String(header).length;
      rows.forEach((item) => {
        const value = item[header];
        if (value !== null && value !== undefined) {
          const text = typeof value === 'string' ? value : String(value);
          maxLength = Math.max(maxLength, text.length);
        }
      });
      worksheet.getColumn(index + 1).width = Math.max(maxLength + 2, 10);
    });
  });

  const blob = new Blob([await workbook.xlsx.writeBuffer()], {
    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  });
  saveAs(blob, fileName);
};

export default exportExcel;
