import { createContext, use, useEffect, useMemo, Suspense } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import dayjs from 'dayjs';
import Loader from './Loader';
import { useAsyncTask } from '../../reactHelper';
import { sessionActions } from '../../store';
import fetchOrThrow from '../util/fetchOrThrow';

import fa from '../../resources/l10n/fa.json';
import 'dayjs/locale/fa';

const languages = {
  fa: { country: 'IR', name: 'فارسی' },
};

const language = 'fa';

const localePromise = Promise.resolve({
  data: fa,
  dayjsName: 'fa',
});

const LocalizationContext = createContext({
  languages,
  language,
  setLocalLanguage: () => {},
  direction: 'rtl',
});

const ResolvedLocalizationProvider = ({ children }) => {
  const { data, dayjsName } = use(localePromise);

  const direction = 'rtl';

  const value = useMemo(
    () => ({
      languages: { ...languages, [language]: { ...languages[language], data } },
      language,
      setLocalLanguage: () => {},
      direction,
    }),
    [data],
  );

  useEffect(() => {
    dayjs.locale(dayjsName);
    document.dir = direction;
  }, [dayjsName, direction]);

  return <LocalizationContext value={value}>{children}</LocalizationContext>;
};

export const LocalizationProvider = ({ children }) => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.session.user);
  const serverLanguage = useSelector((state) => state.session.server?.attributes?.language);

  useAsyncTask(
    async ({ signal }) => {
      if (user && !user.attributes.language && !serverLanguage) {
        const response = await fetchOrThrow(`api/users/${user.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ ...user, attributes: { ...user.attributes, language } }),
          signal,
        });
        const updatedUser = await response.json();
        signal.throwIfAborted();
        dispatch(sessionActions.updateUser(updatedUser));
      }
    },
    [user, serverLanguage, dispatch],
  );

  return (
    <Suspense fallback={<Loader />}>
      <ResolvedLocalizationProvider>{children}</ResolvedLocalizationProvider>
    </Suspense>
  );
};

export const useLocalization = () => use(LocalizationContext);

export const useTranslation = () => {
  const context = use(LocalizationContext);
  const { data } = context.languages[context.language];
  return useMemo(() => (key) => data[key], [data]);
};

export const useTranslationKeys = (predicate) => {
  const context = use(LocalizationContext);
  const { data } = context.languages[context.language];
  return Object.keys(data).filter(predicate);
};
