import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import {
  Table,
  TableRow,
  TableCell,
  TableHead,
  TableBody,
  IconButton,
  Tooltip,
} from '@mui/material';
import { makeStyles } from 'tss-react/mui';
import CheckCircleOutlineIcon from '@mui/icons-material/CheckCircleOutlined';
import HelpOutlineIcon from '@mui/icons-material/HelpOutlined';
import VerticalAlignBottomIcon from '@mui/icons-material/VerticalAlignBottom';
import { useTranslation } from '../common/components/LocalizationProvider';
import PageLayout from '../common/components/PageLayout';
import BaseFab from '../common/components/BaseFab';
import ReportsMenu from './components/ReportsMenu';
import { sessionActions } from '../store';

const useStyles = makeStyles()((theme) => ({
  columnAction: {
    width: '1%',
    paddingLeft: theme.spacing(1),
  },
}));

const LogsPage = () => {
  const { classes } = useStyles();
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const t = useTranslation();
  const [autoScroll, setAutoScroll] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => {
    dispatch(sessionActions.enableLogs(true));
    return () => dispatch(sessionActions.enableLogs(false));
  }, [dispatch]);

  const items = useSelector((state) => state.session.logs);

  useEffect(() => {
    if (autoScroll) {
      bottomRef.current?.scrollIntoView({ block: 'end', inline: 'nearest' });
    }
  }, [autoScroll, items.length]);

  const registerDevice = (uniqueId) => {
    const query = new URLSearchParams({ uniqueId });
    navigate(`/settings/device?${query.toString()}`);
  };

  return (
    <PageLayout menu={<ReportsMenu />} breadcrumbs={['reportTitle', 'sharedLogs']}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell className={classes.columnAction} />
            <TableCell>{t('deviceIdentifier')}</TableCell>
            <TableCell>{t('positionProtocol')}</TableCell>
            <TableCell>{t('commandData')}</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {items.map((item, index) => (
            <TableRow key={index}>
              <TableCell className={classes.columnAction} padding="none">
                {item.deviceId ? (
                  <IconButton color="success" size="small" disabled>
                    <CheckCircleOutlineIcon fontSize="small" />
                  </IconButton>
                ) : (
                  <Tooltip title={t('loginRegister')}>
                    <IconButton
                      color="error"
                      size="small"
                      onClick={() => registerDevice(item.uniqueId)}
                    >
                      <HelpOutlineIcon fontSize="small" />
                    </IconButton>
                  </Tooltip>
                )}
              </TableCell>
              <TableCell>{item.uniqueId}</TableCell>
              <TableCell>{item.protocol}</TableCell>
              <TableCell>{item.data}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
      <div ref={bottomRef} />
      <BaseFab
        color={autoScroll ? 'primary' : 'default'}
        onClick={() => setAutoScroll(!autoScroll)}
      >
        <VerticalAlignBottomIcon />
      </BaseFab>
    </PageLayout>
  );
};

export default LogsPage;
