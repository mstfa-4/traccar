/*
 * Copyright 2017 - 2026 Anton Tananaev (anton@traccar.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.traccar.protocol;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import org.traccar.BasePipelineFactory;
import org.traccar.BaseProtocol;
import org.traccar.BaseProtocolEncoder;
import org.traccar.Protocol;
import org.traccar.config.Keys;
import org.traccar.helper.CharsetUtil;
import org.traccar.helper.DataConverter;
import org.traccar.helper.model.AttributeUtil;
import org.traccar.model.Command;

import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Set;

public class Jt808ProtocolEncoder extends BaseProtocolEncoder {

    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter
            .ofPattern("yyMMddHHmmss").withZone(ZoneId.systemDefault());

    public Jt808ProtocolEncoder(Protocol protocol) {
        super(protocol);
    }

    @Override
    protected Object encodeCommand(Channel channel, Command command) {

        Jt808ProtocolDecoder decoder = BasePipelineFactory.getHandler(
                channel.pipeline(), Jt808ProtocolDecoder.class);

        boolean alternative = AttributeUtil.lookup(
                getCacheManager(), Keys.PROTOCOL_ALTERNATIVE.withPrefix(getProtocolName()), command.getDeviceId());

        Integer protocolVersion = decoder.getProtocolVersion();
        ByteBuf id = Jt808ProtocolDecoder.encodeId(
                getUniqueId(command.getDeviceId()), protocolVersion != null ? 10 : 6);
        String model = getDeviceModel(command.getDeviceId());
        try {
            ByteBuf data = Unpooled.buffer();

            switch (command.getType()) {
                case Command.TYPE_CUSTOM:
                    if (model != null && Set.of("AL300", "GL100", "VL300").contains(model)) {
                        data.writeByte(1); // number of parameters
                        data.writeInt(0xF030); // AT command transparent transmission
                        int length = command.getString(Command.KEY_DATA).length();
                        data.writeByte(length);
                        data.writeCharSequence(command.getString(Command.KEY_DATA), StandardCharsets.US_ASCII);
                        return decoder.formatMessage(
                                Jt808ProtocolDecoder.MSG_CONFIGURATION_PARAMETERS, id, false, data);
                    } else if (model != null && Set.of("BSJ", "C5", "C5L").contains(model)) {
                        data.writeByte(1); // flag
                        data.writeCharSequence(command.getString(Command.KEY_DATA), CharsetUtil.GBK);
                        return decoder.formatMessage(
                                Jt808ProtocolDecoder.MSG_SEND_TEXT_MESSAGE, id, false, data);
                    } else if (model != null && model.startsWith("JC")) {
                        data.writeByte(0xF0); // online command
                        data.writeCharSequence(command.getString(Command.KEY_DATA), StandardCharsets.US_ASCII);
                        return decoder.formatMessage(
                                Jt808ProtocolDecoder.MSG_TRANSPARENT_DOWNLINK, id, false, data);
                    } else {
                        return Unpooled.wrappedBuffer(DataConverter.parseHex(command.getString(Command.KEY_DATA)));
                    }
                case Command.TYPE_REBOOT_DEVICE:
                    data.writeByte(1); // number of parameters
                    data.writeByte(0x23); // parameter id
                    data.writeByte(1); // parameter value length
                    data.writeByte(0x03); // restart
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_PARAMETER_SETTING, id, false, data);
                case Command.TYPE_POSITION_PERIODIC:
                    data.writeByte(1); // number of parameters
                    data.writeByte(0x06); // parameter id
                    data.writeByte(4); // parameter value length
                    data.writeInt(command.getInteger(Command.KEY_FREQUENCY));
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_PARAMETER_SETTING, id, false, data);
                case Command.TYPE_POSITION_SINGLE:
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_LOCATION_QUERY, id, false, data);
                case Command.TYPE_POSITION_STOP:
                    data.writeShort(0);
                    data.writeInt(0);
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_TEMPORARY_TRACKING, id, false, data);
                case Command.TYPE_ALARM_ARM:
                case Command.TYPE_ALARM_DISARM:
                    data.writeByte(1); // number of parameters
                    data.writeByte(0x24); // parameter id
                    String username = "user";
                    data.writeByte(1 + username.length()); // parameter value length
                    data.writeByte(command.getType().equals(Command.TYPE_ALARM_ARM) ? 0x01 : 0x00);
                    data.writeCharSequence(username, StandardCharsets.US_ASCII);
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_PARAMETER_SETTING, id, false, data);
                case Command.TYPE_ALARM_DISMISS:
                    data.writeShort(0);
                    data.writeInt(0);
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_ALARM_ACK, id, false, data);
                case Command.TYPE_ENGINE_STOP:
                case Command.TYPE_ENGINE_RESUME:
                    if (alternative) {
                        data.writeByte(command.getType().equals(Command.TYPE_ENGINE_STOP) ? 0x01 : 0x00);
                        data.writeBytes(DataConverter.parseHex(DATE_FORMAT.format(Instant.now())));
                        return decoder.formatMessage(
                                Jt808ProtocolDecoder.MSG_OIL_CONTROL, id, false, data);
                    } else {
                        if ("VL300".equals(model)) {
                            data.writeCharSequence(command.getType().equals(Command.TYPE_ENGINE_STOP) ? "#0;1" : "#0;0",
                                    StandardCharsets.US_ASCII);
                        } else if ("W15L".equals(model)) {
                            data.writeByte(command.getType().equals(Command.TYPE_ENGINE_STOP) ? 0x64 : 0x65);
                        } else {
                            data.writeByte(command.getType().equals(Command.TYPE_ENGINE_STOP) ? 0xf0 : 0xf1);
                        }
                        return decoder.formatMessage(
                                Jt808ProtocolDecoder.MSG_TERMINAL_CONTROL, id, false, data);
                    }
                case Command.TYPE_SET_CONNECTION:
                    data.writeByte(2); // number of parameters
                    String server = command.getString(Command.KEY_SERVER);
                    data.writeInt(0x13); // server address
                    data.writeByte(server.length());
                    data.writeCharSequence(server, StandardCharsets.US_ASCII);
                    data.writeInt(0x18); // server tcp port
                    data.writeByte(4);
                    data.writeInt(command.getInteger(Command.KEY_PORT));
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_CONFIGURATION_PARAMETERS, id, false, data);
                case Command.TYPE_POWER_OFF:
                    data.writeByte(0x02); // power off
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_TERMINAL_CONTROL, id, false, data);
                case Command.TYPE_FACTORY_RESET:
                    data.writeByte(0x03); // factory reset
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_TERMINAL_CONTROL, id, false, data);
                case Command.TYPE_MESSAGE:
                    data.writeByte(0x04); // display on terminal
                    data.writeCharSequence(command.getString(Command.KEY_MESSAGE), CharsetUtil.GBK);
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_SEND_TEXT_MESSAGE, id, false, data);
                case Command.TYPE_VOICE_MESSAGE:
                    data.writeByte(0x08); // tts voice broadcast
                    data.writeCharSequence(command.getString(Command.KEY_MESSAGE), CharsetUtil.GBK);
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_SEND_TEXT_MESSAGE, id, false, data);
                case Command.TYPE_REQUEST_PHOTO:
                    data.writeByte(command.getInteger(Command.KEY_INDEX, 0)); // channel
                    data.writeShort(1); // take one photo
                    data.writeZero(9); // photo interval and image parameters
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_TAKE_PHOTO, id, false, data);
                case Command.TYPE_SET_SPEED_LIMIT:
                    boolean hasDuration = command.hasAttribute(Command.KEY_DURATION);
                    data.writeByte(hasDuration ? 2 : 1); // number of parameters
                    data.writeInt(0x0055); // overspeed threshold
                    data.writeByte(4);
                    data.writeInt(command.getInteger(Command.KEY_DATA));
                    if (hasDuration) {
                        data.writeInt(0x0056); // overspeed duration
                        data.writeByte(4);
                        data.writeInt(command.getInteger(Command.KEY_DURATION));
                    }
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_CONFIGURATION_PARAMETERS, id, false, data);
                case Command.TYPE_OUTPUT_CONTROL:
                    data.writeByte(command.getInteger(Command.KEY_INDEX, 0)); // control flag
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_VEHICLE_CONTROL, id, false, data);
                case Command.TYPE_CONFIGURATION:
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_PARAMETER_QUERY_ALL, id, false, data);
                case Command.TYPE_VIDEO_START:
                    var config = getCacheManager().getConfig();
                    String host = URI.create(config.getString(Keys.WEB_URL)).getHost();
                    int port = config.getInteger(
                            Keys.PROTOCOL_PORT.withPrefix(BaseProtocol.nameFromClass(Jt1078Protocol.class)));
                    int videoChannel = command.getInteger(Command.KEY_INDEX, 1);
                    data.writeByte(host.length());
                    data.writeCharSequence(host, StandardCharsets.US_ASCII);
                    data.writeShort(port); // tcp port
                    data.writeShort(0); // udp port
                    data.writeByte(videoChannel);
                    data.writeByte(1); // video only
                    data.writeByte(0); // main stream
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_VIDEO_REQUEST, id, false, data);
                case Command.TYPE_VIDEO_STOP:
                    data.writeByte(command.getInteger(Command.KEY_INDEX, 1));
                    data.writeByte(0); // close audio/video transmission
                    data.writeByte(0); // close both audio and video
                    data.writeByte(0); // main stream
                    return decoder.formatMessage(
                            Jt808ProtocolDecoder.MSG_VIDEO_CONTROL, id, false, data);
                default:
                    return null;
            }
        } finally {
            id.release();
        }
    }

}
