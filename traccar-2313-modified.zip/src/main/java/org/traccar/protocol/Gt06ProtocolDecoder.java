/*
 * Copyright 2012 - 2026 Anton Tananaev (anton@traccar.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.traccar.protocol;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;
import io.netty.channel.Channel;
import org.traccar.BaseProtocolDecoder;
import org.traccar.NetworkMessage;
import org.traccar.Protocol;
import org.traccar.helper.BcdUtil;
import org.traccar.helper.BitUtil;
import org.traccar.helper.BufferUtil;
import org.traccar.helper.Checksum;
import org.traccar.helper.DateBuilder;
import org.traccar.helper.Parser;
import org.traccar.helper.PatternBuilder;
import org.traccar.helper.StringUtil;
import org.traccar.helper.UnitsConverter;
import org.traccar.model.CellTower;
import org.traccar.model.Network;
import org.traccar.model.Position;
import org.traccar.model.WifiAccessPoint;
import org.traccar.session.DeviceSession;

import java.net.SocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.TimeZone;
import java.util.regex.Pattern;

public class Gt06ProtocolDecoder extends BaseProtocolDecoder {

    public Gt06ProtocolDecoder(Protocol protocol) {
        super(protocol);
    }

    public static final int MSG_LOGIN = 0x01;
    public static final int MSG_GPS = 0x10;
    public static final int MSG_GPS_LBS_6 = 0x11;
    public static final int MSG_GPS_LBS_1 = 0x12;
    public static final int MSG_GPS_LBS_2 = 0x22;
    public static final int MSG_GPS_LBS_DRIVER = 0x25;     // XT40
    public static final int MSG_GPS_LBS_3 = 0x37;
    public static final int MSG_GPS_LBS_4 = 0x2D;
    public static final int MSG_STATUS = 0x13;
    public static final int MSG_SATELLITE = 0x14;
    public static final int MSG_STRING = 0x15;
    public static final int MSG_GPS_LBS_STATUS_1 = 0x16;
    public static final int MSG_WIFI = 0x17;
    public static final int MSG_GPS_LBS_RFID = 0x17;
    public static final int MSG_LBS_ADDRESS_REQUEST = 0x17;
    public static final int MSG_GPS_LBS_STATUS_2 = 0x26;
    public static final int MSG_GPS_LBS_STATUS_3 = 0x27;
    public static final int MSG_LBS_MULTIPLE_1 = 0x28;
    public static final int MSG_LBS_MULTIPLE_2 = 0x2E;
    public static final int MSG_LBS_MULTIPLE_3 = 0x24;
    public static final int MSG_LBS_WIFI = 0x2C;
    public static final int MSG_LBS_EXTEND = 0x18;
    public static final int MSG_LBS_STATUS = 0x19;
    public static final int MSG_GPS_PHONE = 0x1A;
    public static final int MSG_GPS_LBS_EXTEND = 0x1E;     // JI09
    public static final int MSG_HEARTBEAT = 0x23;          // GK310
    public static final int MSG_ADDRESS_REQUEST = 0x2A;    // GK310
    public static final int MSG_ADDRESS_RESPONSE = 0x97;   // GK310
    public static final int MSG_GPS_LBS_5 = 0x31;          // AZ735 & SL4X
    public static final int MSG_GPS_LBS_STATUS_4 = 0x32;   // AZ735 & SL4X
    public static final int MSG_WIFI_5 = 0x33;             // AZ735 & SL4X
    public static final int MSG_LBS_3 = 0x34;              // SL4X
    public static final int MSG_AZ735_GPS = 0x32;          // AZ735 (extended)
    public static final int MSG_AZ735_ALARM = 0x33;        // AZ735 (only extended)
    public static final int MSG_X1_GPS = 0x34;
    public static final int MSG_X1_PHOTO_INFO = 0x35;
    public static final int MSG_X1_PHOTO_DATA = 0x36;
    public static final int MSG_LOCATION_RFID = 0x36;      // TRX16i
    public static final int MSG_STATUS_2 = 0x36;           // Jimi IoT 4G
    public static final int MSG_ALARM_MODULE = 0x39;       // Jimi IoT 4G
    public static final int MSG_WIFI_ALARM = 0xA9;         // Jimi IoT 4G
    public static final int MSG_ATTENDANCE = 0xB0;         // Jimi IoT 4G
    public static final int MSG_BLUETOOTH_CLOCK = 0xB2;    // Jimi IoT 4G
    public static final int MSG_DEVICE_STATUS = 0xF1;      // Jimi IoT 4G
    public static final int MSG_WIFI_2 = 0x69;
    public static final int MSG_GPS_MODULAR = 0x70;
    public static final int MSG_WIFI_4 = 0xF3;
    public static final int MSG_COMMAND_0 = 0x80;
    public static final int MSG_COMMAND_1 = 0x81;
    public static final int MSG_COMMAND_2 = 0x82;
    public static final int MSG_TIME_REQUEST = 0x8A;       // GK310
    public static final int MSG_INFO = 0x94;
    public static final int MSG_SERIAL = 0x9B;
    public static final int MSG_STRING_INFO = 0x21;
    public static final int MSG_GPS_LBS_7 = 0xA0;          // GK310 & JM-VL03
    public static final int MSG_LBS_2 = 0xA1;              // GK310
    public static final int MSG_WIFI_3 = 0xA2;             // GK310
    public static final int MSG_GPS_LBS_STATUS_5 = 0xA2;   // LWxG
    public static final int MSG_FENCE_SINGLE = 0xA3;       // GK310
    public static final int MSG_FENCE_MULTI = 0xA4;        // GK310 & JM-LL301
    public static final int MSG_LBS_ALARM = 0xA5;          // GK310 & JM-LL301
    public static final int MSG_LBS_ADDRESS = 0xA7;        // GK310
    public static final int MSG_OBD = 0x8C;                // FM08ABC
    public static final int MSG_DTC = 0x65;                // FM08ABC
    public static final int MSG_PID = 0x66;                // FM08ABC
    public static final int MSG_BMS = 0x40;                // WD-209
    public static final int MSG_MULTIMEDIA = 0x41;         // WD-209
    public static final int MSG_ALARM = 0x95;              // JC100
    public static final int MSG_PERIPHERAL = 0xF2;         // VL842
    public static final int MSG_STATUS_3 = 0xA3;           // GL21L
    public static final int MSG_GPS_LBS_8 = 0x38;
    public static final int MSG_IBUTTON = 0x61;

    private static final Set<String> NT_MODELS = Set.of("NT11", "NT20", "NT26", "NT40", "NT46", "VL100", "XT40");
    private static final Set<String> VL_MODELS = Set.of("VL103", "LL303", "VL512", "G18");

    private enum Variant {
        VXT01,
        WANWAY_S20,
        SR411_MINI,
        GT06E_CARD,
        BENWAY,
        S5,
        SPACE10X,
        STANDARD,
        OBD6,
        WETRUST,
        JC400,
        SL4X,
        SEEWORLD,
        RFID,
        LW4G,
        TRX16I,
    }

    private Variant variant;

    private static final Pattern PATTERN_FUEL = new PatternBuilder()
            .text("!AIOIL,")
            .number("d+,")                       // device address
            .number("d+.d+,")                    // output value
            .number("(d+.d+),")                  // temperature
            .expression("[^,]+,")                // version
            .number("dd")                        // back wave
            .number("d")                         // software status code
            .number("d,")                        // hardware status code
            .number("(d+.d+),")                  // measured value
            .expression("[01],")                 // movement status
            .number("d+,")                       // excited wave times
            .number("xx")                        // checksum
            .compile();

    private static final Pattern PATTERN_LOCATION = new PatternBuilder()
            .text("Current position!")
            .number("Lat:([NS])(d+.d+),")        // latitude
            .number("Lon:([EW])(d+.d+),")        // longitude
            .text("Course:").number("(d+.d+),")  // course
            .text("Speed:").number("(d+.d+),")   // speed
            .text("DateTime:")
            .number("(dddd)-(dd)-(dd) +")        // date
            .number("(dd):(dd):(dd)")            // time
            .compile();

    private boolean isSupported(int type, String model) {
        return hasGps(type) || hasLbs(type) || hasStatus(type, model);
    }

    private boolean hasGps(int type) {
        switch (type) {
            case MSG_GPS:
            case MSG_GPS_LBS_1:
            case MSG_GPS_LBS_2:
            case MSG_GPS_LBS_DRIVER:
            case MSG_GPS_LBS_3:
            case MSG_GPS_LBS_4:
            case MSG_GPS_LBS_5:
            case MSG_GPS_LBS_6:
            case MSG_GPS_LBS_STATUS_1:
            case MSG_GPS_LBS_STATUS_2:
            case MSG_GPS_LBS_STATUS_3:
            case MSG_GPS_LBS_STATUS_4:
            case MSG_GPS_LBS_STATUS_5:
            case MSG_GPS_PHONE:
            case MSG_GPS_LBS_EXTEND:
            case MSG_GPS_LBS_7:
            case MSG_GPS_LBS_RFID:
            case MSG_FENCE_MULTI:
            case MSG_ALARM_MODULE:
                return true;
            case 0xA3: // MSG_FENCE_SINGLE / MSG_STATUS_3
                return variant != Variant.SEEWORLD;
            default:
                return false;
        }
    }

    private boolean hasLbs(int type) {
        switch (type) {
            case MSG_LBS_STATUS:
            case MSG_GPS_LBS_1:
            case MSG_GPS_LBS_2:
            case MSG_GPS_LBS_DRIVER:
            case MSG_GPS_LBS_3:
            case MSG_GPS_LBS_4:
            case MSG_GPS_LBS_5:
            case MSG_GPS_LBS_6:
            case MSG_GPS_LBS_STATUS_1:
            case MSG_GPS_LBS_STATUS_2:
            case MSG_GPS_LBS_STATUS_3:
            case MSG_GPS_LBS_STATUS_4:
            case MSG_GPS_LBS_STATUS_5:
            case MSG_GPS_LBS_7:
            case MSG_GPS_LBS_RFID:
            case MSG_FENCE_MULTI:
            case MSG_ALARM_MODULE:
            case MSG_LBS_ALARM:
            case MSG_LBS_ADDRESS:
                return true;
            case 0xA3: // MSG_FENCE_SINGLE / MSG_STATUS_3
                return variant != Variant.SEEWORLD;
            default:
                return false;
        }
    }

    private boolean hasStatus(int type, String model) {
        switch (type) {
            case MSG_STATUS:
            case MSG_STATUS_2:
            case MSG_LBS_STATUS:
            case MSG_GPS_LBS_STATUS_1:
            case MSG_GPS_LBS_STATUS_2:
            case MSG_GPS_LBS_STATUS_3:
            case MSG_GPS_LBS_STATUS_4:
            case MSG_GPS_LBS_STATUS_5:
            case MSG_FENCE_MULTI:
            case MSG_ALARM_MODULE:
            case MSG_LBS_ALARM:
                return true;
            case MSG_GPS_LBS_2:
            case MSG_GPS_LBS_DRIVER:
                return model != null && NT_MODELS.contains(model.toUpperCase(Locale.ROOT));
            case 0xA3: // MSG_FENCE_SINGLE / MSG_STATUS_3
                return variant == Variant.SEEWORLD;
            default:
                return false;
        }
    }

    private void sendResponse(Channel channel, boolean extended, int type, int index, ByteBuf content) {
        if (channel != null) {
            ByteBuf response = Unpooled.buffer();
            int length = 5 + (content != null ? content.readableBytes() : 0);
            if (extended) {
                response.writeShort(0x7979);
                response.writeShort(length);
            } else {
                response.writeShort(0x7878);
                response.writeByte(length);
            }
            response.writeByte(type);
            if (content != null) {
                response.writeBytes(content);
                content.release();
            }
            response.writeShort(index);
            response.writeShort(Checksum.crc16(Checksum.CRC16_X25,
                    response.nioBuffer(2, response.writerIndex() - 2)));
            response.writeByte('\r');
            response.writeByte('\n');
            channel.writeAndFlush(new NetworkMessage(response, channel.remoteAddress()));
        }
    }

    private void sendPhotoRequest(Channel channel, int pictureId) {
        ByteBuf photo = getMediaBuffer();
        ByteBuf content = Unpooled.buffer();
        content.writeInt(pictureId);
        content.writeInt(photo.writerIndex());
        content.writeShort(Math.min(photo.maxWritableBytes(), 1024));
        sendResponse(channel, false, MSG_X1_PHOTO_DATA, 0, content);
    }

    public static boolean decodeGps(Position position, ByteBuf buf, boolean hasLength, TimeZone timezone) {
        return decodeGps(position, buf, hasLength, true, true, false, false, timezone);
    }

    public static boolean decodeGps(
            Position position, ByteBuf buf, boolean hasLength, boolean hasSatellites,
            boolean hasSpeed, boolean longSpeed, boolean swapFlags, TimeZone timezone) {

        DateBuilder dateBuilder = new DateBuilder(timezone)
                .setDate(buf.readUnsignedByte(), buf.readUnsignedByte(), buf.readUnsignedByte())
                .setTime(buf.readUnsignedByte(), buf.readUnsignedByte(), buf.readUnsignedByte());
        position.setTime(dateBuilder.getDate());

        if (hasLength && buf.readUnsignedByte() == 0) {
            return false;
        }

        if (hasSatellites) {
            position.set(Position.KEY_SATELLITES, BitUtil.to(buf.readUnsignedByte(), 4));
        }

        double latitude = buf.readUnsignedInt() / 60.0 / 30000.0;
        double longitude = buf.readUnsignedInt() / 60.0 / 30000.0;

        int flags = 0;
        if (swapFlags) {
            flags = buf.readUnsignedShort();
        }
        if (hasSpeed) {
            position.setSpeed(UnitsConverter.knotsFromKph(
                    longSpeed ? buf.readUnsignedShort() : buf.readUnsignedByte()));
        }
        if (!swapFlags) {
            flags = buf.readUnsignedShort();
        }

        position.setCourse(BitUtil.to(flags, 10));
        position.setValid(BitUtil.check(flags, 12));

        if (!BitUtil.check(flags, 10)) {
            latitude = -latitude;
        }
        if (BitUtil.check(flags, 11)) {
            longitude = -longitude;
        }

        position.setLatitude(latitude);
        position.setLongitude(longitude);

        if (BitUtil.check(flags, 14)) {
            position.set(Position.KEY_IGNITION, BitUtil.check(flags, 15));
        }

        return true;
    }

    private boolean decodeLbs(Position position, ByteBuf buf, int type, boolean hasLength) {

        int length = 0;
        if (hasLength) {
            length = buf.readUnsignedByte();
            if (length == 0) {
                boolean zeroedData = true;
                for (int i = buf.readerIndex() + 9; i < buf.readerIndex() + 45 && i < buf.writerIndex(); i++) {
                    if (buf.getByte(i) != 0) {
                        zeroedData = false;
                        break;
                    }
                }
                if (zeroedData) {
                    buf.skipBytes(Math.min(buf.readableBytes(), 45));
                }
                return false;
            }
        }

        boolean shortLbs = type == MSG_GPS_LBS_6 && buf.readableBytes() == 14;
        int cellType = type == MSG_GPS_LBS_8 || type == MSG_ALARM_MODULE ? buf.readUnsignedByte() : 0;
        int mcc = buf.readUnsignedShort();
        int mnc;
        if (BitUtil.check(mcc, 15) || (type == MSG_GPS_LBS_6 && !shortLbs) || variant == Variant.SL4X) {
            mnc = buf.readUnsignedShort();
        } else {
            mnc = buf.readUnsignedByte();
        }
        int lac;
        if (cellType >= 3 || type == MSG_LBS_ALARM || type == MSG_GPS_LBS_7 || type == MSG_GPS_LBS_STATUS_5) {
            lac = buf.readInt();
        } else {
            lac = buf.readUnsignedShort();
        }
        long cid;
        if (cellType >= 3 || type == MSG_LBS_ALARM || type == MSG_GPS_LBS_7 || variant == Variant.SL4X
                || type == MSG_GPS_LBS_STATUS_5) {
            cid = buf.readLong();
        } else if ((type == MSG_GPS_LBS_6 && !shortLbs) || type == MSG_IBUTTON || type == MSG_GPS_LBS_DRIVER
                || variant == Variant.SEEWORLD || (variant == Variant.TRX16I && type == MSG_LOCATION_RFID)) {
            cid = buf.readUnsignedInt();
        } else {
            cid = buf.readUnsignedMedium();
        }
        if (cellType >= 3) {
            buf.readUnsignedShort(); // rssi
        } else if (type == MSG_GPS_LBS_8 || type == MSG_ALARM_MODULE) {
            buf.readUnsignedByte(); // rssi
        }

        position.setNetwork(new Network(CellTower.from(BitUtil.to(mcc, 15), mnc, lac, cid)));

        if (length > 9) {
            buf.skipBytes(length - 9);
        }

        return true;
    }

    private void decodeStatus(Position position, ByteBuf buf) {

        int status = buf.readUnsignedByte();

        position.set(Position.KEY_STATUS, status);
        position.set(Position.KEY_IGNITION, BitUtil.check(status, 1));
        position.set(Position.KEY_CHARGE, BitUtil.check(status, 2));
        position.set(Position.KEY_BLOCKED, BitUtil.check(status, 7));

        switch (BitUtil.between(status, 3, 6)) {
            case 1:
                position.addAlarm(Position.ALARM_VIBRATION);
                break;
            case 2:
                position.addAlarm(Position.ALARM_POWER_CUT);
                break;
            case 3:
                position.addAlarm(Position.ALARM_LOW_BATTERY);
                break;
            case 4:
                position.addAlarm(Position.ALARM_SOS);
                break;
            case 6:
                position.addAlarm(Position.ALARM_GEOFENCE);
                break;
            case 7:
                if (variant == Variant.VXT01) {
                    position.addAlarm(Position.ALARM_OVERSPEED);
                } else {
                    position.addAlarm(Position.ALARM_REMOVING);
                }
                break;
            default:
                break;
        }
    }

    private String decodeAlarm(int value, boolean modelLW, boolean modelSW, boolean modelVL) {
        return switch (value) {
            case 0x01 -> Position.ALARM_SOS;
            case 0x02 -> Position.ALARM_POWER_CUT;
            case 0x03 -> Position.ALARM_VIBRATION;
            case 0x04 -> Position.ALARM_GEOFENCE_ENTER;
            case 0x05 -> Position.ALARM_GEOFENCE_EXIT;
            case 0x06 -> Position.ALARM_OVERSPEED;
            case 0x09 -> variant == Variant.TRX16I ? Position.ALARM_GEOFENCE
                    : modelVL ? Position.ALARM_TOW : Position.ALARM_VIBRATION;
            case 0x0E -> variant == Variant.TRX16I ? Position.ALARM_LOW_POWER : Position.ALARM_LOW_BATTERY;
            case 0x0F -> Position.ALARM_LOW_BATTERY;
            case 0x11 -> Position.ALARM_POWER_OFF;
            case 0x0C, 0x13, 0x25, 0x32 -> Position.ALARM_TAMPERING;
            case 0x14 -> Position.ALARM_DOOR;
            case 0x18 -> modelLW ? Position.ALARM_ACCIDENT : Position.ALARM_REMOVING;
            case 0x19 -> modelLW ? Position.ALARM_ACCELERATION : Position.ALARM_LOW_BATTERY;
            case 0x1A, 0x27, 0xF1 -> Position.ALARM_BRAKING;
            case 0x1B, 0x2A, 0x2B, 0x2E -> Position.ALARM_CORNERING;
            case 0x23 -> Position.ALARM_FALL_DOWN;
            case 0x26, 0xF0 -> Position.ALARM_ACCELERATION;
            case 0x28 -> modelSW ? Position.ALARM_CORNERING
                    : modelVL ? Position.ALARM_POWER_OFF : Position.ALARM_BRAKING;
            case 0x29 -> modelSW ? Position.ALARM_ACCIDENT : Position.ALARM_ACCELERATION;
            case 0x2C, 0xF2 -> Position.ALARM_ACCIDENT;
            case 0x30 -> modelVL ? Position.ALARM_BRAKING : Position.ALARM_JAMMING;
            case 0x33 -> Position.ALARM_LOCK;
            case 0x34 -> Position.ALARM_UNLOCK;
            case 0x53 -> Position.ALARM_FUEL_LEAK;
            case 0x5B, 0x5C -> Position.ALARM_TEMPERATURE;
            case 0xC9 -> Position.ALARM_IDLE;
            case 0x0107, 0x010B -> Position.ALARM_JAMMING;
            default -> null;
        };
    }

    @Override
    protected Object decode(
            Channel channel, SocketAddress remoteAddress, Object msg) throws Exception {

        ByteBuf buf = (ByteBuf) msg;

        decodeVariant(buf);

        boolean extended = buf.readShort() != 0x7878;

        int length = extended ? buf.readUnsignedShort() : buf.readUnsignedByte();
        int dataLength = length - 5;
        int type = buf.readUnsignedByte();

        Position position = new Position(getProtocolName());
        DeviceSession deviceSession = null;
        if (type != MSG_LOGIN) {
            deviceSession = getDeviceSession(channel, remoteAddress);
            if (deviceSession == null) {
                return null;
            }
            position.setDeviceId(deviceSession.getDeviceId());
            if (!deviceSession.contains(DeviceSession.KEY_TIMEZONE)) {
                deviceSession.set(DeviceSession.KEY_TIMEZONE, getTimeZone(deviceSession.getDeviceId()));
            }
        }

        String model = deviceSession != null ? getDeviceModel(deviceSession) : null;
        if (model != null) {
            model = model.toUpperCase(Locale.ROOT);
        }
        boolean modelLW = model != null && model.startsWith("LW");
        boolean modelSW = "SEEWORLD".equals(model);
        boolean modelNT = model != null && NT_MODELS.contains(model);
        boolean modelVL = model != null && VL_MODELS.contains(model);

        if (type == MSG_LOGIN) {

            String imei = ByteBufUtil.hexDump(buf.readSlice(8)).substring(1);
            buf.readUnsignedShort(); // type

            deviceSession = getDeviceSession(channel, remoteAddress, imei);
            if (deviceSession != null) {
                TimeZone timeZone = getTimeZone(deviceSession.getDeviceId(), null);
                if (timeZone == null && dataLength > 10) {
                    int extensionBits = buf.readUnsignedShort();
                    int hours = (extensionBits >> 4) / 100;
                    int minutes = (extensionBits >> 4) % 100;
                    int offset = (hours * 60 + minutes) * 60;
                    if ((extensionBits & 0x8) != 0) {
                        offset = -offset;
                    }
                    timeZone = TimeZone.getTimeZone("UTC");
                    timeZone.setRawOffset(offset * 1000);
                }
                deviceSession.set(DeviceSession.KEY_TIMEZONE, timeZone);

                sendResponse(channel, false, type, buf.getShort(buf.writerIndex() - 6), null);
            }

            return null;

        } else if (type == MSG_HEARTBEAT) {

            getLastLocation(position, null);

            int status = buf.readUnsignedByte();
            position.set(Position.KEY_ARMED, BitUtil.check(status, 0));
            position.set(Position.KEY_IGNITION, BitUtil.check(status, 1));
            position.set(Position.KEY_CHARGE, BitUtil.check(status, 2));

            if (buf.readableBytes() >= 2 + 6) {
                position.set(Position.KEY_BATTERY, buf.readUnsignedShort() / 100.0);
            }
            if (buf.readableBytes() >= 1 + 6) {
                position.set(Position.KEY_RSSI, buf.readUnsignedByte());
            }

            sendResponse(channel, false, type, buf.getShort(buf.writerIndex() - 6), null);

            return position;

        } else if (type == MSG_ADDRESS_REQUEST || (type == MSG_LBS_ADDRESS_REQUEST
                && length == buf.readableBytes() - 1
                && length == (BitUtil.check(buf.getUnsignedShort(buf.readerIndex()), 15) ? 0x25 : 0x24))) {

            String response = "NA&&NA&&0##";
            ByteBuf content = Unpooled.buffer();
            content.writeByte(response.length());
            content.writeInt(0);
            content.writeBytes(response.getBytes(StandardCharsets.US_ASCII));
            sendResponse(channel, true, MSG_ADDRESS_RESPONSE, 0, content);

            return null;

        } else if (type == MSG_TIME_REQUEST) {

            Calendar calendar = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
            ByteBuf content = Unpooled.buffer();
            content.writeByte(calendar.get(Calendar.YEAR) - 2000);
            content.writeByte(calendar.get(Calendar.MONTH) + 1);
            content.writeByte(calendar.get(Calendar.DAY_OF_MONTH));
            content.writeByte(calendar.get(Calendar.HOUR_OF_DAY));
            content.writeByte(calendar.get(Calendar.MINUTE));
            content.writeByte(calendar.get(Calendar.SECOND));
            sendResponse(channel, false, MSG_TIME_REQUEST, 0, content);

            return null;

        } else if (type == MSG_X1_GPS && variant != Variant.SL4X) {

            buf.readUnsignedInt(); // data and alarm

            decodeGps(position, buf, false, deviceSession.get(DeviceSession.KEY_TIMEZONE));

            buf.readUnsignedShort(); // terminal info

            position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());

            position.setNetwork(new Network(CellTower.from(
                    buf.readUnsignedShort(), buf.readUnsignedByte(),
                    buf.readUnsignedShort(), buf.readUnsignedInt())));

            long driverId = buf.readUnsignedInt();
            if (driverId > 0) {
                position.set(Position.KEY_DRIVER_UNIQUE_ID, String.valueOf(driverId));
            }

            position.set(Position.KEY_BATTERY, buf.readUnsignedShort() / 100.0);
            position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);

            long portInfo = buf.readUnsignedInt();

            position.set(Position.KEY_INPUT, buf.readUnsignedByte());
            position.set(Position.KEY_OUTPUT, buf.readUnsignedByte());

            for (int i = 1; i <= BitUtil.between(portInfo, 20, 24); i++) {
                position.set(Position.PREFIX_ADC + i, buf.readUnsignedShort() / 100.0);
            }

            return position;

        } else if (type == MSG_X1_PHOTO_INFO) {

            buf.skipBytes(6); // time
            buf.readUnsignedByte(); // fix status
            buf.readUnsignedInt(); // latitude
            buf.readUnsignedInt(); // longitude
            buf.readUnsignedByte(); // camera id
            buf.readUnsignedByte(); // photo source
            buf.readUnsignedByte(); // picture format

            newMediaBuffer(buf.readInt());
            int pictureId = buf.readInt();
            sendPhotoRequest(channel, pictureId);

            return null;

        } else if ((type == MSG_WIFI && variant != Variant.RFID) || type == MSG_WIFI_2 || type == MSG_WIFI_4) {

            ByteBuf time = buf.readSlice(6);
            DateBuilder dateBuilder = new DateBuilder()
                    .setYear(BcdUtil.readInteger(time, 2))
                    .setMonth(BcdUtil.readInteger(time, 2))
                    .setDay(BcdUtil.readInteger(time, 2))
                    .setHour(BcdUtil.readInteger(time, 2))
                    .setMinute(BcdUtil.readInteger(time, 2))
                    .setSecond(BcdUtil.readInteger(time, 2));
            getLastLocation(position, dateBuilder.getDate());

            Network network = new Network();

            int wifiCount;
            if (type == MSG_WIFI_4) {
                wifiCount = buf.readUnsignedByte();
            } else {
                wifiCount = buf.getUnsignedByte(2);
            }

            for (int i = 0; i < wifiCount; i++) {
                if (type == MSG_WIFI_4) {
                    buf.skipBytes(2);
                }
                WifiAccessPoint wifiAccessPoint = new WifiAccessPoint();
                wifiAccessPoint.setMacAddress(String.format("%02x:%02x:%02x:%02x:%02x:%02x",
                        buf.readUnsignedByte(), buf.readUnsignedByte(), buf.readUnsignedByte(),
                        buf.readUnsignedByte(), buf.readUnsignedByte(), buf.readUnsignedByte()));
                if (type != MSG_WIFI_4) {
                    wifiAccessPoint.setSignalStrength((int) buf.readUnsignedByte());
                }
                network.addWifiAccessPoint(wifiAccessPoint);
            }

            if (type != MSG_WIFI_4) {

                int cellCount = buf.readUnsignedByte();
                int mcc = buf.readUnsignedShort();
                int mnc = buf.readUnsignedByte();
                for (int i = 0; i < cellCount; i++) {
                    network.addCellTower(CellTower.from(
                            mcc, mnc, buf.readUnsignedShort(), buf.readUnsignedShort(), buf.readUnsignedByte()));
                }

                if (channel != null) {
                    ByteBuf response = Unpooled.buffer();
                    response.writeShort(0x7878);
                    response.writeByte(0);
                    response.writeByte(type);
                    response.writeBytes(time.resetReaderIndex());
                    response.writeByte('\r');
                    response.writeByte('\n');
                    channel.writeAndFlush(new NetworkMessage(response, channel.remoteAddress()));
                }

            }

            position.setNetwork(network);

            return position;

        } else if (type == MSG_INFO && !extended) {

            getLastLocation(position, null);

            position.set(Position.KEY_POWER, buf.readShort() / 100.0);

            return position;

        } else if (type == MSG_LBS_MULTIPLE_3 && variant == Variant.SR411_MINI) {

            decodeGps(position, buf, false, deviceSession.get(DeviceSession.KEY_TIMEZONE));

            decodeLbs(position, buf, type, false);

            position.set(Position.KEY_IGNITION, buf.readUnsignedByte() > 0);
            position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
            position.set(Position.KEY_BATTERY, buf.readUnsignedShort() / 100.0);

            return position;

        } else if (type == MSG_LBS_MULTIPLE_1 || type == MSG_LBS_MULTIPLE_2 || type == MSG_LBS_MULTIPLE_3
                || type == MSG_LBS_EXTEND || type == MSG_LBS_WIFI || type == MSG_LBS_2 || type == MSG_LBS_3
                || (type == MSG_WIFI_3 && variant != Variant.LW4G) || (type == MSG_WIFI_5 && !extended)
                || type == MSG_WIFI_ALARM) {

            getLastLocation(position, decodeDate(buf, deviceSession));

            if (variant == Variant.WANWAY_S20 || variant == Variant.SL4X) {
                buf.readUnsignedByte(); // ta
            }

            int mcc = buf.readUnsignedShort();
            int mnc = BitUtil.check(mcc, 15) || variant == Variant.SL4X
                    ? buf.readUnsignedShort() : buf.readUnsignedByte();
            Network network = new Network();

            boolean cell4g = type == MSG_WIFI_ALARM && buf.readUnsignedByte() > 0;
            boolean sharedLac = type == MSG_LBS_EXTEND && length == 0x25;
            boolean shortCellId = type == MSG_LBS_MULTIPLE_1 && buf.readableBytes() == 36;
            int lac = sharedLac ? buf.readUnsignedShort() : 0;

            int cellCount = variant == Variant.WANWAY_S20 || type == MSG_WIFI_ALARM
                    || (variant == Variant.SL4X && type == MSG_LBS_3)
                    ? buf.readUnsignedByte() : type == MSG_WIFI_5 || shortCellId ? 6 : 7;
            for (int i = 0; i < cellCount; i++) {
                int cid;
                if (sharedLac) {
                    cid = buf.readUnsignedShort();
                } else if (type == MSG_LBS_2 || type == MSG_WIFI_3 || cell4g) {
                    lac = buf.readInt();
                    cid = (int) buf.readLong();
                } else if (type == MSG_WIFI_5 || type == MSG_LBS_3) {
                    lac = buf.readUnsignedShort();
                    cid = (int) buf.readUnsignedInt();
                } else {
                    lac = buf.readUnsignedShort();
                    cid = shortCellId ? buf.readUnsignedShort() : buf.readUnsignedMedium();
                }
                int rssi = -buf.readUnsignedByte();
                if (cid > 0) {
                    network.addCellTower(CellTower.from(BitUtil.to(mcc, 15), mnc, lac, cid, rssi));
                }
            }

            if (!sharedLac && !shortCellId && variant != Variant.WANWAY_S20 && variant != Variant.SL4X) {
                buf.readUnsignedByte(); // ta
            }

            if (!sharedLac && type != MSG_LBS_MULTIPLE_1 && type != MSG_LBS_MULTIPLE_2 && type != MSG_LBS_MULTIPLE_3
                    && type != MSG_LBS_2 && type != MSG_LBS_3) {
                int wifiCount = buf.readUnsignedByte();
                for (int i = 0; i < wifiCount; i++) {
                    String mac = ByteBufUtil.hexDump(buf.readSlice(6)).replaceAll("(..)", "$1:");
                    network.addWifiAccessPoint(WifiAccessPoint.from(
                            mac.substring(0, mac.length() - 1), buf.readUnsignedByte()));
                }
            }

            position.setNetwork(network);

            if (type == MSG_WIFI_ALARM) {
                int alarm = buf.readUnsignedByte();
                int language = buf.readUnsignedByte();
                position.addAlarm(decodeAlarm((language >> 4) << 8 | alarm, modelLW, modelSW, modelVL));
            }

        } else if (type == MSG_BLUETOOTH_CLOCK) {

            getLastLocation(position, decodeDate(buf, deviceSession));

            position.set(Position.KEY_RSSI, buf.readByte());
            position.set("tagMac", ByteBufUtil.hexDump(buf.readSlice(6)));
            position.set("tagUuid", ByteBufUtil.hexDump(buf.readSlice(16)));
            position.set("tagMajor", buf.readUnsignedShort());
            position.set("tagMinor", buf.readUnsignedShort());
            position.set("tagBattery", buf.readUnsignedShort() / 100.0);
            position.set("clock", BitUtil.between(buf.readUnsignedByte(), 2, 6));

        } else if (type == MSG_STRING) {

            getLastLocation(position, null);

            int commandLength = buf.readUnsignedByte();

            if (commandLength > 0) {
                buf.readUnsignedInt(); // server flag (reserved)
                String data = buf.readSlice(commandLength - 4).toString(StandardCharsets.US_ASCII);
                if (data.startsWith("<ICCID:")) {
                    position.set(Position.KEY_ICCID, data.substring(7, 27));
                } else {
                    position.set(Position.KEY_RESULT, data);
                }
            }

        } else if (type == MSG_BMS) {

            buf.skipBytes(8); // serial number

            getLastLocation(position, new Date(buf.readUnsignedInt() * 1000));

            position.set("relativeCapacity", buf.readUnsignedByte());
            position.set("remainingCapacity", buf.readUnsignedShort());
            position.set("absoluteCapacity", buf.readUnsignedByte());
            position.set("fullCapacity", buf.readUnsignedShort());
            position.set("batteryHealth", buf.readUnsignedByte());
            position.set("batteryTemp", buf.readUnsignedShort() / 10.0 - 273.1);
            position.set("current", buf.readUnsignedShort());
            position.set(Position.KEY_BATTERY, buf.readUnsignedShort() / 1000.0);
            position.set("cycleIndex", buf.readUnsignedShort());
            for (int i = 1; i <= 14; i++) {
                position.set("batteryCell" + i, buf.readUnsignedShort() / 1000.0);
            }
            position.set("currentChargeInterval", buf.readUnsignedShort());
            position.set("maxChargeInterval", buf.readUnsignedShort());
            position.set("barcode", buf.readCharSequence(16, StandardCharsets.US_ASCII).toString().trim());
            position.set("batteryVersion", buf.readUnsignedShort());
            position.set("manufacturer", buf.readCharSequence(16, StandardCharsets.US_ASCII).toString().trim());
            position.set("batteryStatus", buf.readUnsignedInt());

            position.set("controllerStatus", buf.readUnsignedInt());
            position.set("controllerFault", buf.readUnsignedInt());

            sendResponse(channel, false, type, buf.getShort(buf.writerIndex() - 6), null);

            return position;

        } else if (type == MSG_STATUS && buf.readableBytes() == 22) {

            getLastLocation(position, null);

            buf.readUnsignedByte(); // information content
            buf.readUnsignedShort(); // satellites
            buf.readUnsignedByte(); // alarm
            buf.readUnsignedByte(); // language

            position.set(Position.KEY_BATTERY_LEVEL, buf.readUnsignedByte());

            buf.readUnsignedByte(); // working mode
            buf.readUnsignedShort(); // working voltage
            buf.readUnsignedByte(); // reserved
            buf.readUnsignedShort(); // working times
            buf.readUnsignedShort(); // working time

            int value = buf.readUnsignedShort();
            double temperature = BitUtil.to(value, 15) / 10.0;
            position.set(Position.PREFIX_TEMP + 1, BitUtil.check(value, 15) ? temperature : -temperature);

        } else if (type == MSG_IBUTTON) {

            buf.skipBytes(8); // imei

            decodeGps(position, buf, false, deviceSession.get(DeviceSession.KEY_TIMEZONE));

            decodeLbs(position, buf, type, false);

            long driverUniqueId = (buf.readUnsignedInt() << 16) | buf.readUnsignedShort();
            position.set(Position.KEY_DRIVER_UNIQUE_ID, String.valueOf(driverUniqueId));

        } else if (type == MSG_LOCATION_RFID && variant == Variant.TRX16I) {

            decodeGps(position, buf, false, deviceSession.get(DeviceSession.KEY_TIMEZONE));

            decodeLbs(position, buf, type, false);

            position.set(Position.KEY_IGNITION, buf.readUnsignedByte() > 0);
            position.set("uploadMode", buf.readUnsignedByte());
            position.set(Position.KEY_ARCHIVE, buf.readUnsignedByte() > 0);

            position.set(Position.KEY_ODOMETER, buf.readUnsignedInt()); // unit unconfirmed
            position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
            position.set(Position.KEY_BATTERY, buf.readUnsignedByte() / 10.0);
            position.set(Position.KEY_HOURS, buf.readUnsignedMedium() * 60 * 1000L);

            String rfid = ByteBufUtil.hexDump(buf.readSlice(8));
            if (!rfid.matches("0+")) {
                position.set(Position.KEY_DRIVER_UNIQUE_ID, rfid);
            }

        } else if (isSupported(type, model)
                && !(extended && (type == MSG_GPS_LBS_STATUS_4 || type == MSG_STATUS_2))) {

            if (type == MSG_LBS_STATUS && variant == Variant.SPACE10X) {
                return null; // multi-lbs message
            }

            position.set(Position.KEY_TYPE, type);

            if (type == MSG_GPS_LBS_1 && "QH302R".equals(model)) {
                buf.skipBytes(8); // imei
            }
            if ((type == MSG_GPS_LBS_2 || type == MSG_GPS_LBS_DRIVER) && modelNT) {
                buf.readUnsignedByte(); // location source type
                buf.skipBytes(8); // imei
                position.setDeviceTime(decodeDate(buf, deviceSession));
            }

            if (type == MSG_GPS_LBS_6 && length == 0x13) {
                getLastLocation(position, decodeDate(buf, deviceSession));
            } else if (hasGps(type)) {
                decodeGps(position, buf, false, deviceSession.get(DeviceSession.KEY_TIMEZONE));
            } else {
                getLastLocation(position, null);
            }

            if (hasLbs(type) && buf.readableBytes() > 6) {
                boolean hasLength = hasStatus(type, model)
                        && type != MSG_LBS_STATUS
                        && type != MSG_LBS_ALARM
                        && type != MSG_ALARM_MODULE
                        && (type != MSG_GPS_LBS_STATUS_1 || variant != Variant.VXT01)
                        && type != MSG_GPS_LBS_STATUS_5;
                decodeLbs(position, buf, type, hasLength);
            }

            if (hasStatus(type, model)) {
                if (type == MSG_GPS_LBS_STATUS_5) {
                    buf.readUnsignedByte(); // network indicator
                }
                decodeStatus(position, buf);
                if (variant == Variant.OBD6) {
                    int signal = buf.readUnsignedShort();
                    int satellites = BitUtil.between(signal, 10, 15) + BitUtil.between(signal, 5, 10);
                    position.set(Position.KEY_SATELLITES, satellites);
                    position.set(Position.KEY_RSSI, BitUtil.to(signal, 5));
                    position.addAlarm(decodeAlarm(buf.readUnsignedByte(), modelLW, modelSW, modelVL));
                    buf.readUnsignedByte(); // language
                    position.set(Position.KEY_BATTERY_LEVEL, buf.readUnsignedByte());
                    int mode = buf.readUnsignedByte();
                    position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                    buf.readUnsignedByte(); // reserved
                    buf.readUnsignedShort(); // working time
                    if (mode == 4) {
                        position.set(Position.PREFIX_TEMP + 1, buf.readShort() / 10.0);
                    }
                } else if (variant == Variant.SEEWORLD && length == 0x18) {
                    buf.readUnsignedShort(); // extension bit status
                    buf.readUnsignedByte(); // voltage level
                    position.set(Position.KEY_RSSI, buf.readUnsignedByte());
                    position.set(Position.KEY_POWER, (double) buf.readUnsignedByte());
                    buf.readUnsignedByte(); // language
                    buf.readUnsignedByte(); // sound switch
                    buf.readUnsignedByte(); // light switch
                    position.set(Position.KEY_STEPS, buf.readUnsignedInt());
                    position.set(Position.KEY_BATTERY_LEVEL, buf.readUnsignedByte());
                    position.set(Position.KEY_CHARGE, buf.readUnsignedByte() == 1);
                    position.set(Position.KEY_MOTION, buf.readUnsignedByte() == 1);
                } else {
                    if (type == MSG_GPS_LBS_STATUS_5
                            || (modelNT && (type == MSG_GPS_LBS_2 || type == MSG_GPS_LBS_DRIVER))) {
                        position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                    }
                    if (type == MSG_STATUS && "R11".equals(model)) {
                        position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                    } else {
                        int battery = buf.readUnsignedByte();
                        if (modelNT && (type == MSG_GPS_LBS_2 || type == MSG_GPS_LBS_DRIVER)) {
                            position.set(Position.KEY_BATTERY, battery / 10.0);
                        } else if (battery <= 6) {
                            position.set(Position.KEY_BATTERY_LEVEL, battery * 100 / 6);
                        } else if (battery <= 100) {
                            position.set(Position.KEY_BATTERY_LEVEL, battery);
                        }
                    }
                    position.set(Position.KEY_RSSI, buf.readUnsignedByte());
                    if (type == MSG_STATUS && modelLW) {
                        position.set(Position.KEY_POWER, BitUtil.to(buf.readUnsignedShort(), 12) / 10.0);
                    } else {
                        int extension = buf.readUnsignedByte();
                        if (type == MSG_GPS_LBS_STATUS_3 || type == MSG_FENCE_MULTI
                                || type == MSG_ALARM_MODULE) {
                            extension += (buf.getUnsignedByte(buf.readerIndex()) >> 4) << 8;
                        }
                        if (type == MSG_STATUS && modelSW) {
                            position.set(Position.KEY_POWER, (double) extension);
                        } else if (variant != Variant.VXT01) {
                            position.addAlarm(decodeAlarm(extension, modelLW, modelSW, modelVL));
                            if (variant == Variant.TRX16I) {
                                position.set(Position.KEY_EVENT, extension);
                            }
                        }
                    }
                }
            }

            if (type == MSG_STATUS_2 || type == MSG_GPS_LBS_STATUS_5 || type == MSG_GPS_LBS_STATUS_3
                    || type == MSG_FENCE_MULTI || type == MSG_ALARM_MODULE
                    || modelNT && (type == MSG_GPS_LBS_2 || type == MSG_GPS_LBS_DRIVER)) {
                buf.readUnsignedByte(); // language
            }

            if (type == MSG_GPS_LBS_STATUS_1 && variant == Variant.TRX16I) {
                buf.readUnsignedByte(); // language
                String rfid = ByteBufUtil.hexDump(buf.readSlice(8));
                if (!rfid.matches("0+")) {
                    position.set(Position.KEY_DRIVER_UNIQUE_ID, rfid);
                }
            }

            if (type == MSG_STATUS_2 || type == MSG_ALARM_MODULE) {
                while (buf.readableBytes() > 6) {
                    int moduleType = buf.readUnsignedShort();
                    int moduleLength = buf.readUnsignedByte();
                    switch (moduleType) {
                        case 0x0018 -> position.set(Position.KEY_BATTERY, buf.readUnsignedShort() / 100.0);
                        case 0x0032 -> position.set("startupStatus", buf.readUnsignedByte());
                        case 0x006A -> position.set(Position.KEY_BATTERY_LEVEL, buf.readUnsignedByte());
                        default -> buf.skipBytes(moduleLength);
                    }
                }
            }

            if (type == MSG_GPS_LBS_STATUS_5) {
                position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());
                position.set(Position.KEY_HOURS, buf.readUnsignedInt() * 1000);
                buf.skipBytes(8); // terminal id
                position.set(Position.KEY_INPUT, buf.readUnsignedShort());
            }

            if (type == MSG_GPS_LBS_1) {
                if (variant == Variant.GT06E_CARD) {
                    position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());
                    String data = buf.readCharSequence(buf.readUnsignedByte(), StandardCharsets.US_ASCII).toString();
                    buf.readUnsignedByte(); // alarm
                    buf.readUnsignedByte(); // swiped
                    position.set(Position.KEY_CARD, data.trim());
                } else if (variant == Variant.BENWAY) {
                    int mask = buf.readUnsignedShort();
                    position.set(Position.KEY_IGNITION, BitUtil.check(mask, 8 + 7));
                    position.set(Position.PREFIX_IN + 2, BitUtil.check(mask, 8 + 6));
                    if (BitUtil.check(mask, 8 + 4)) {
                        int value = BitUtil.to(mask, 8 + 1);
                        if (BitUtil.check(mask, 8 + 1)) {
                            value = -value;
                        }
                        position.set(Position.PREFIX_TEMP + 1, value);
                    } else {
                        int value = BitUtil.to(mask, 8 + 2);
                        if (BitUtil.check(mask, 8 + 5)) {
                            position.set(Position.PREFIX_ADC + 1, value);
                        } else {
                            position.set(Position.PREFIX_ADC + 1, value / 10.0);
                        }
                    }
                } else if (variant == Variant.VXT01) {
                    decodeStatus(position, buf);
                    position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                    position.set(Position.KEY_RSSI, buf.readUnsignedByte());
                    buf.readUnsignedByte(); // alarm extension
                } else if (variant == Variant.S5) {
                    decodeStatus(position, buf);
                    position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                    position.set(Position.KEY_RSSI, buf.readUnsignedByte());
                    position.addAlarm(decodeAlarm(buf.readUnsignedByte(), modelLW, modelSW, modelVL));
                    position.set("oil", buf.readUnsignedShort());
                    int temperature = buf.readUnsignedByte();
                    if (BitUtil.check(temperature, 7)) {
                        temperature = -BitUtil.to(temperature, 7);
                    }
                    position.set(Position.PREFIX_TEMP + 1, temperature);
                    position.set(Position.KEY_ODOMETER, buf.readUnsignedInt() * 10);
                } else if (variant == Variant.WETRUST) {
                    position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());
                    position.set(Position.KEY_CARD, buf.readCharSequence(
                            buf.readUnsignedByte(), StandardCharsets.US_ASCII).toString());
                    position.addAlarm(buf.readUnsignedByte() > 0 ? Position.ALARM_GENERAL : null);
                    position.set("cardStatus", buf.readUnsignedByte());
                    position.set(Position.KEY_DRIVING_TIME, buf.readUnsignedShort());
                }
            }

            if (type == MSG_GPS_LBS_2 && variant == Variant.SEEWORLD) {
                position.set(Position.KEY_IGNITION, buf.readUnsignedByte() > 0);
                buf.readUnsignedByte(); // reporting mode
                buf.readUnsignedByte(); // supplementary transmission
                position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());
                buf.readUnsignedInt(); // travel time
                int temperature = buf.readUnsignedShort();
                if (BitUtil.check(temperature, 15)) {
                    temperature = -BitUtil.to(temperature, 15);
                }
                position.set(Position.PREFIX_TEMP + 1, temperature / 100.0);
                position.set(Position.KEY_HUMIDITY, buf.readUnsignedShort() / 100.0);
            }

            if (type == MSG_GPS_LBS_STATUS_4 && variant == Variant.SL4X) {
                position.setAltitude(buf.readShort());
            }

            if ((type == MSG_GPS_LBS_2 || type == MSG_GPS_LBS_3 || type == MSG_GPS_LBS_4 || type == MSG_GPS_LBS_5)
                    && buf.readableBytes() >= 3 + 6 && !modelNT) {
                position.set(Position.KEY_IGNITION, buf.readUnsignedByte() > 0);
                position.set(Position.KEY_EVENT, buf.readUnsignedByte()); // reason
                position.set(Position.KEY_ARCHIVE, buf.readUnsignedByte() > 0);
                if (variant == Variant.SL4X) {
                    if (buf.readableBytes() > 2 + 6) {
                        position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());
                    }
                    position.setAltitude(buf.readShort());
                }
            }

            if (type == MSG_GPS_LBS_3) {
                int module = buf.readUnsignedShort();
                int subLength = buf.readUnsignedByte();
                switch (module) {
                    case 0x0027 -> position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                    case 0x002E -> position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());
                    case 0x003B -> position.setAccuracy(buf.readUnsignedShort() / 100.0);
                    default -> buf.skipBytes(subLength);
                }
            }

            if (type == MSG_GPS_LBS_RFID) {
                position.set(Position.KEY_DRIVER_UNIQUE_ID, ByteBufUtil.hexDump(buf.readSlice(8)));
                buf.readUnsignedByte(); // validity
            }

            if (modelNT && (type == MSG_GPS_LBS_2 || type == MSG_GPS_LBS_DRIVER)) {
                position.set(Position.KEY_ODOMETER, buf.readUnsignedMedium());
                position.set(Position.KEY_HOURS, buf.readUnsignedMedium() * 60 * 1000L);
            }

            if (modelNT && type == MSG_GPS_LBS_DRIVER) {
                int driverLength = buf.readUnsignedByte();
                if (driverLength > 0) {
                    buf.readUnsignedByte(); // driver identifier type
                    position.set(Position.KEY_DRIVER_UNIQUE_ID,
                            ByteBufUtil.hexDump(buf.readSlice(driverLength - 1)));
                }
            }

            if (buf.readableBytes() == 3 + 6 || buf.readableBytes() == 3 + 4 + 6) {
                position.set(Position.KEY_IGNITION, buf.readUnsignedByte() > 0);
                buf.readUnsignedByte(); // upload mode
                position.set(Position.KEY_ARCHIVE, buf.readUnsignedByte() > 0 ? true : null);
            }

            if (buf.readableBytes() == 4 + 6) {
                position.set(Position.KEY_ODOMETER, buf.readUnsignedInt());
            }

            if (type == MSG_GPS_LBS_STATUS_3 || type == MSG_FENCE_MULTI) {
                position.set(Position.KEY_GEOFENCE, buf.readUnsignedByte());
            }

        } else if (type == MSG_ALARM) {

            boolean jc400 = variant == Variant.JC400;
            boolean extendedAlarm = dataLength > 7;
            if (extendedAlarm) {
                if (jc400) {
                    buf.readUnsignedShort(); // marker
                    buf.readUnsignedByte(); // version
                }
                decodeGps(
                        position, buf, false, jc400, jc400, jc400, jc400,
                        deviceSession.get(DeviceSession.KEY_TIMEZONE));
            } else {
                getLastLocation(position, decodeDate(buf, deviceSession));
            }
            if (variant == Variant.JC400) {
                position.set(Position.KEY_POWER, buf.readUnsignedShort() / 10.0);
            }
            short event = buf.readUnsignedByte();
            position.set(Position.KEY_EVENT, event);
            position.set("eventData", buf.readUnsignedShort());
            switch (event) {
                case 0x01 -> position.addAlarm(extendedAlarm ? Position.ALARM_SOS : Position.ALARM_GENERAL);
                case 0x0E -> position.addAlarm(Position.ALARM_LOW_POWER);
                case 0x76 -> position.addAlarm(Position.ALARM_TEMPERATURE);
                case 0x80 -> position.addAlarm(Position.ALARM_VIBRATION);
                case 0x87 -> position.addAlarm(Position.ALARM_OVERSPEED);
                case 0x88 -> position.addAlarm(Position.ALARM_POWER_CUT);
                case 0x90 -> position.addAlarm(Position.ALARM_ACCELERATION);
                case 0x91 -> position.addAlarm(Position.ALARM_BRAKING);
                case 0x92 -> position.addAlarm(Position.ALARM_CORNERING);
                case 0x93 -> position.addAlarm(Position.ALARM_ACCIDENT);
            }

            int filesLength = buf.readableBytes() - 6;
            if (filesLength > 0) {
                position.set("eventFiles", buf.readCharSequence(filesLength, StandardCharsets.US_ASCII).toString());
            }

        } else if (type == MSG_STRING_INFO) {

            buf.readUnsignedInt(); // server flag
            String data;
            if (buf.readUnsignedByte() == 1) {
                data = buf.readSlice(buf.readableBytes() - 6).toString(StandardCharsets.US_ASCII);
            } else {
                data = buf.readSlice(buf.readableBytes() - 6).toString(StandardCharsets.UTF_16BE);
            }

            Parser parser = new Parser(PATTERN_LOCATION, data);

            if (parser.matches()) {
                position.setValid(true);
                position.setLatitude(parser.nextCoordinate(Parser.CoordinateFormat.HEM_DEG));
                position.setLongitude(parser.nextCoordinate(Parser.CoordinateFormat.HEM_DEG));
                position.setCourse(parser.nextDouble());
                position.setSpeed(parser.nextDouble());
                position.setTime(parser.nextDateTime(Parser.DateTimeFormat.YMD_HMS));
            } else {
                getLastLocation(position, null);
                position.set(Position.KEY_RESULT, data);
            }

            return position;

        } else if (type == MSG_INFO) {

            int subType = buf.readUnsignedByte();

            getLastLocation(position, null);

            if (subType == 0x00) {

                position.set(Position.PREFIX_ADC + 1, buf.readUnsignedShort() / 100.0);
                return position;

            } else if (subType == 0x04) {

                CharSequence content = buf.readCharSequence(buf.readableBytes() - 4 - 2, StandardCharsets.US_ASCII);
                String[] values = content.toString().split(";");
                for (String value : values) {
                    String[] pair = value.split("=");
                    switch (pair[0]) {
                        case "ALM1":
                        case "ALM2":
                        case "ALM3":
                        case "ALM4":
                            position.set("alarm" + pair[0].charAt(3) + "Status", Integer.parseInt(pair[1], 16));
                            break;
                        case "STA1":
                            position.set("otherStatus", Integer.parseInt(pair[1], 16));
                            break;
                        case "DYD":
                            position.set("engineStatus", Integer.parseInt(pair[1], 16));
                            break;
                        default:
                            break;
                    }
                }
                return position;

            } else if (subType == 0x05) {

                if (buf.readableBytes() >= 6 + 1 + 6) {
                    position.setDeviceTime(decodeDate(buf, deviceSession));
                }

                int flags = buf.readUnsignedByte();
                position.set(Position.KEY_DOOR, BitUtil.check(flags, 0));
                position.set(Position.PREFIX_IO + 1, BitUtil.check(flags, 2));
                return position;

            } else if (subType == 0x0a) {

                if (buf.readableBytes() > 16) {
                    buf.skipBytes(8); // imei
                    buf.skipBytes(8); // imsi
                }
                position.set(Position.KEY_ICCID, StringUtil.stripTrailing(
                        'f', ByteBufUtil.hexDump(buf.readSlice(10))));
                return position;

            } else if (subType == 0x0b) {

                int contentLength = length - 6;
                if (contentLength == 1) {
                    position.set("networkTechnology", buf.readByte() > 0 ? "4G" : "2G");
                } else if (contentLength == 2) {
                    position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                }
                return position;

            } else if (subType == 0x0d) {

                if (buf.getByte(buf.readerIndex()) != '!') {
                    buf.skipBytes(6);
                }

                Parser parser = new Parser(PATTERN_FUEL, buf.toString(
                        buf.readerIndex(), buf.readableBytes() - 4 - 2, StandardCharsets.US_ASCII));
                if (!parser.matches()) {
                    return null;
                }

                position.set(Position.PREFIX_TEMP + 1, parser.nextDouble(0));
                position.set(Position.KEY_FUEL, parser.nextDouble(0));

                return position;

            } else if (subType == 0x15) {

                int count = buf.readUnsignedByte();
                for (int i = 1; i <= count; i++) {
                    buf.skipBytes(8); // sensor id
                    position.set(Position.PREFIX_TEMP + i, buf.readShort() / 100.0);
                }
                return position;

            } else if (subType == 0x1b) {

                if (Character.isLetter(buf.getUnsignedByte(buf.readerIndex()))) {
                    String data = buf.readCharSequence(buf.readableBytes() - 6, StandardCharsets.US_ASCII).toString();
                    position.set("serial", data.trim());
                } else {
                    buf.readUnsignedByte(); // header
                    buf.readUnsignedByte(); // type
                    position.set(Position.KEY_DRIVER_UNIQUE_ID, ByteBufUtil.hexDump(buf.readSlice(4)));
                    buf.readUnsignedByte(); // checksum
                    buf.readUnsignedByte(); // footer
                }
                return position;

            } else if (subType == 0x1e) {

                position.set(Position.PREFIX_TEMP + 1, buf.readInt() / 10.0);
                position.set(Position.KEY_HUMIDITY, buf.readInt() / 10.0);

                return position;

            }

            return null;

        } else if (type == MSG_X1_PHOTO_DATA) {

            int pictureId = buf.readInt();

            ByteBuf photo = getMediaBuffer();

            buf.readUnsignedInt(); // offset
            photo.writeBytes(buf, buf.readUnsignedShort());

            if (photo.maxWritableBytes() > 0) {
                sendPhotoRequest(channel, pictureId);
            } else {
                position.set(Position.KEY_IMAGE, writeMediaFile(deviceSession.getUniqueId(), "jpg"));
            }

            return null;

        } else if (type == MSG_AZ735_GPS || type == MSG_AZ735_ALARM) {

            if (!decodeGps(position, buf, true, deviceSession.get(DeviceSession.KEY_TIMEZONE))) {
                getLastLocation(position, position.getDeviceTime());
            }

            if (decodeLbs(position, buf, type, true)) {
                position.set(Position.KEY_RSSI, buf.readUnsignedByte());
            }

            buf.skipBytes(buf.readUnsignedByte()); // additional cell towers
            buf.skipBytes(buf.readUnsignedByte()); // wifi access point

            int status = buf.readUnsignedByte();
            position.set(Position.KEY_STATUS, status);

            if (type == MSG_AZ735_ALARM) {
                switch (status) {
                    case 0xA0 -> position.set(Position.KEY_ARMED, true);
                    case 0xA1 -> position.set(Position.KEY_ARMED, false);
                    case 0xA2, 0xA3 -> position.addAlarm(Position.ALARM_LOW_BATTERY);
                    case 0xA4 -> position.addAlarm(Position.ALARM_GENERAL);
                    case 0xA5 -> position.addAlarm(Position.ALARM_DOOR);
                }
            }

            buf.skipBytes(buf.readUnsignedByte()); // reserved extension

            sendResponse(channel, true, type, buf.getShort(buf.writerIndex() - 6), null);

            return position;

        } else if (type == MSG_OBD) {

            getLastLocation(position, decodeDate(buf, deviceSession));

            position.set(Position.KEY_IGNITION, buf.readUnsignedByte() > 0);

            String data = buf.readCharSequence(buf.readableBytes() - 18, StandardCharsets.US_ASCII).toString();
            for (String pair : data.split(",")) {
                String[] values = pair.split("=");
                if (values.length >= 2) {
                    switch (Integer.parseInt(values[0].substring(0, 2), 16)) {
                        case 40 -> position.set(Position.KEY_ODOMETER, Integer.parseInt(values[1], 16) / 100.0);
                        case 43 -> position.set(Position.KEY_FUEL, Integer.parseInt(values[1], 16) / 100.0);
                        case 45 -> position.set(Position.KEY_COOLANT_TEMP, Integer.parseInt(values[1], 16) / 100.0);
                        case 53 -> position.set(Position.KEY_OBD_SPEED, Integer.parseInt(values[1], 16) / 100.0);
                        case 54 -> position.set(Position.KEY_RPM, Integer.parseInt(values[1], 16) / 100.0);
                        case 71 -> position.set(Position.KEY_FUEL_USED, Integer.parseInt(values[1], 16) / 100.0);
                        case 73 -> position.set(Position.KEY_HOURS, Integer.parseInt(values[1], 16) / 100.0);
                        case 74 -> position.set(Position.KEY_VIN, values[1]);
                    }
                }
            }

            return position;

        } else if (type == MSG_GPS_MODULAR) {

            while (buf.readableBytes() > 6) {
                int moduleType = buf.readUnsignedShort();
                int moduleLength = buf.readUnsignedShort();

                switch (moduleType) {
                    case 0x03 -> position.set(Position.KEY_ICCID, ByteBufUtil.hexDump(buf.readSlice(10)));
                    case 0x09 -> position.set(Position.KEY_SATELLITES, buf.readUnsignedByte());
                    case 0x0a -> position.set(Position.KEY_SATELLITES_VISIBLE, buf.readUnsignedByte());
                    case 0x11 -> {
                        CellTower cellTower = CellTower.from(
                                buf.readUnsignedShort(),
                                buf.readUnsignedShort(),
                                buf.readUnsignedShort(),
                                buf.readUnsignedMedium(),
                                buf.readUnsignedByte());
                        if (cellTower.getCellId() > 0) {
                            position.setNetwork(new Network(cellTower));
                        }
                    }
                    case 0x18 -> position.set(Position.KEY_BATTERY, buf.readUnsignedShort() / 100.0);
                    case 0x28 -> position.set(Position.KEY_HDOP, buf.readUnsignedByte() / 10.0);
                    case 0x29 -> position.set(Position.KEY_INDEX, buf.readUnsignedInt());
                    case 0x2a -> {
                        int input = buf.readUnsignedByte();
                        position.set(Position.KEY_DOOR, BitUtil.to(input, 4) > 0);
                        position.set("tamper", BitUtil.from(input, 4) > 0);
                    }
                    case 0x2b -> position.set("bootReason", buf.readUnsignedByte());
                    case 0x2e -> position.set(Position.KEY_ODOMETER, buf.readUnsignedIntLE());
                    case 0x33 -> {
                        position.setTime(new Date(buf.readUnsignedInt() * 1000));
                        position.set(Position.KEY_SATELLITES, buf.readUnsignedByte());
                        position.setAltitude(buf.readShort());

                        double latitude = buf.readUnsignedInt() / 60.0 / 30000.0;
                        double longitude = buf.readUnsignedInt() / 60.0 / 30000.0;
                        position.setSpeed(UnitsConverter.knotsFromKph(buf.readUnsignedByte()));

                        int flags = buf.readUnsignedShort();
                        position.setCourse(BitUtil.to(flags, 10));
                        position.setValid(BitUtil.check(flags, 12));

                        if (!BitUtil.check(flags, 10)) {
                            latitude = -latitude;
                        }
                        if (BitUtil.check(flags, 11)) {
                            longitude = -longitude;
                        }

                        position.setLatitude(latitude);
                        position.setLongitude(longitude);
                    }
                    case 0x34 -> {
                        int event = buf.readUnsignedByte();
                        switch (event) {
                            case 0x10 -> position.addAlarm(Position.ALARM_DOOR);
                            case 0x12 -> position.addAlarm(Position.ALARM_REMOVING);
                            case 0x14 -> position.addAlarm(Position.ALARM_GEOFENCE_ENTER);
                            case 0x15 -> position.addAlarm(Position.ALARM_GEOFENCE_EXIT);
                            case 0x16 -> position.addAlarm(Position.ALARM_TEMPERATURE);
                            case 0x1A -> position.addAlarm(Position.ALARM_LOW_BATTERY);
                            case 0x1B -> position.addAlarm(Position.ALARM_OVERSPEED);
                            case 0x1C -> position.addAlarm(Position.ALARM_POWER_ON);
                            case 0x1D -> position.addAlarm(Position.ALARM_POWER_OFF);
                            case 0x20 -> position.addAlarm(Position.ALARM_VIBRATION);
                            case 0x21 -> position.addAlarm(Position.ALARM_POWER_CUT);
                            case 0x23 -> position.addAlarm(Position.ALARM_TAMPERING);
                        }
                        position.set(Position.KEY_EVENT, event);
                        buf.readUnsignedIntLE(); // time
                        buf.skipBytes(buf.readUnsignedByte()); // content
                    }
                    case 0x7f -> {
                        position.set("tag1Id", ByteBufUtil.hexDump(buf.readSlice(6)));
                        position.set("tag1Battery", buf.readUnsignedShort() / 1000.0);
                        position.set("tag1BatteryLevel", buf.readUnsignedByte());
                        position.set("tag1Temp", buf.readShort() / 10.0);
                        position.set("tag1Humidity", buf.readShort());
                        position.set("tag1Status", buf.readUnsignedByte());
                    }
                    default -> buf.skipBytes(moduleLength);
                }
            }

            if (position.getFixTime() == null) {
                getLastLocation(position, null);
            }

            sendResponse(channel, false, MSG_GPS_MODULAR, buf.readUnsignedShort(), null);

            return position;

        } else if (type == MSG_MULTIMEDIA) {

            buf.skipBytes(8); // serial number
            long timestamp = buf.readUnsignedInt() * 1000;
            buf.skipBytes(4 + 4 + 2 + 1 + 1 + 2); // gps
            buf.skipBytes(2 + 2 + 2 + 2); // cell

            buf.readInt(); // media id
            int mediaLength = buf.readInt();
            int mediaType = buf.readUnsignedByte();
            int mediaFormat = buf.readUnsignedByte();

            if (mediaType == 0 && mediaFormat == 0) {

                buf.readUnsignedByte(); // event

                ByteBuf photo;
                if (buf.readUnsignedShort() == 0) {
                    photo = newMediaBuffer(mediaLength);
                } else {
                    photo = getMediaBuffer();
                }

                if (photo != null) {
                    photo.writeBytes(buf, buf.readableBytes() - 3 * 2);
                    if (photo.maxWritableBytes() == 0) {
                        getLastLocation(position, new Date(timestamp));
                        position.set(Position.KEY_IMAGE, writeMediaFile(deviceSession.getUniqueId(), "jpg"));
                    }
                }

            }

            sendResponse(channel, true, type, buf.getShort(buf.writerIndex() - 6), null);

            return position;

        } else if (type == MSG_SERIAL) {

            getLastLocation(position, null);

            buf.readUnsignedByte(); // external device type code

            ByteBuf data = buf.readSlice(buf.readableBytes() - 6); // index + checksum + footer
            if (BufferUtil.isPrintable(data, data.readableBytes())) {
                String value = data.readCharSequence(data.readableBytes(), StandardCharsets.US_ASCII).toString();
                position.set(Position.KEY_RESULT, value.trim());
            } else {
                position.set(Position.KEY_RESULT, ByteBufUtil.hexDump(data));
            }

            return position;

        } else if (type == MSG_PERIPHERAL || type == MSG_DEVICE_STATUS) {

            getLastLocation(position, new Date(buf.readUnsignedInt() * 1000));

            while (buf.readableBytes() > 6) {
                int statusId = buf.readUnsignedShort();
                if (type == MSG_PERIPHERAL) {
                    switch (statusId) {
                        case 0x000A -> {
                            int statusLength = buf.readUnsignedShort();
                            buf.readUnsignedByte(); // mac address type
                            position.set("mac", ByteBufUtil.hexDump(buf.readSlice(6)));
                            int event = buf.readUnsignedByte();
                            position.set(Position.KEY_EVENT, event);
                            int eventData = buf.readUnsignedByte();
                            position.set("eventData", event > 0 ? eventData : null);
                            position.set("dataType", buf.readUnsignedByte());
                            position.set("dataDetails", ByteBufUtil.hexDump(buf.readSlice(statusLength - 10)));
                        }
                        case 0x000C -> {
                            buf.readUnsignedByte(); // length
                            position.set("externalBatteryLevel", buf.readUnsignedByte());
                            position.set("externalBatteryCharge", buf.readUnsignedByte() > 0 ? true : null);
                            position.set("externalBatteryCycles", buf.readUnsignedShort());
                            buf.skipBytes(6);
                        }
                        default -> {
                            int statusLength = buf.readUnsignedByte();
                            buf.skipBytes(statusLength == 0 ? buf.readUnsignedByte() : statusLength);
                        }
                    }
                } else {
                    int statusLength = buf.readUnsignedByte();
                    switch (statusId) {
                        case 0x0001 -> {
                            int motionStatus = buf.readUnsignedByte();
                            position.set(Position.KEY_MOTION, motionStatus == 0x02 || motionStatus == 0x04);
                        }
                        case 0x0002 -> position.set(Position.KEY_ARMED, buf.readUnsignedByte() > 0);
                        case 0x0004 -> position.set(Position.KEY_IGNITION, buf.readUnsignedByte() > 0);
                        case 0x0005 -> position.set(Position.KEY_POWER, buf.readUnsignedShort() / 100.0);
                        case 0x0007 -> position.set(Position.KEY_CHARGE, buf.readUnsignedByte() > 0);
                        case 0x000A -> position.set("chargeVoltage", buf.readUnsignedShort());
                        case 0x000B -> position.set("batteryTemp", buf.readUnsignedShort() / 10.0);
                        default -> buf.skipBytes(statusLength);
                    }
                }
            }

            sendResponse(channel, false, type, buf.getShort(buf.writerIndex() - 6), null);

            return position;

        } else if (type == MSG_GPS_LBS_8) {

            decodeGps(position, buf, false, deviceSession.get(DeviceSession.KEY_TIMEZONE));

            buf.readUnsignedByte(); // data upload mode
            buf.readUnsignedByte(); // re-upload

            decodeLbs(position, buf, type, false);

            return position;

        } else {

            if (dataLength > 0) {
                buf.skipBytes(dataLength);
            }
            if (!extended && type != MSG_COMMAND_0 && type != MSG_COMMAND_1 && type != MSG_COMMAND_2) {
                sendResponse(channel, false, type, buf.getShort(buf.writerIndex() - 6), null);
            }
            return null;

        }

        sendResponse(channel, false, type, buf.getShort(buf.writerIndex() - 6), null);

        return position;
    }

    private static Date decodeDate(ByteBuf buf, DeviceSession deviceSession) {
        DateBuilder dateBuilder = new DateBuilder((TimeZone) deviceSession.get(DeviceSession.KEY_TIMEZONE))
                .setDate(buf.readUnsignedByte(), buf.readUnsignedByte(), buf.readUnsignedByte())
                .setTime(buf.readUnsignedByte(), buf.readUnsignedByte(), buf.readUnsignedByte());
        return dateBuilder.getDate();
    }

    private void decodeVariant(ByteBuf buf) {
        int header = buf.getUnsignedShort(buf.readerIndex());
        int length;
        int type;
        if (header == 0x7878) {
            length = buf.getUnsignedByte(buf.readerIndex() + 2);
            type = buf.getUnsignedByte(buf.readerIndex() + 2 + 1);
        } else {
            length = buf.getUnsignedShort(buf.readerIndex() + 2);
            type = buf.getUnsignedByte(buf.readerIndex() + 2 + 2);
        }

        if (header == 0x7878 && type == MSG_GPS_LBS_1 && length == 0x24) {
            variant = Variant.VXT01;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_STATUS_1 && length == 0x24) {
            variant = Variant.VXT01;
        } else if (header == 0x7878 && type == MSG_LBS_MULTIPLE_3 && length == 0x31) {
            variant = Variant.WANWAY_S20;
        } else if (header == 0x7878 && type == MSG_LBS_MULTIPLE_3 && length == 0x2e) {
            variant = Variant.SR411_MINI;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_1 && length >= 0x71) {
            variant = Variant.GT06E_CARD;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_1 && length == 0x21) {
            variant = Variant.BENWAY;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_1 && length == 0x2b) {
            variant = Variant.S5;
        } else if (header == 0x7878 && type == MSG_LBS_STATUS && length >= 0x17) {
            variant = Variant.SPACE10X;
        } else if (header == 0x7878 && type == MSG_STATUS && length == 0x13) {
            variant = Variant.OBD6;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_1 && length == 0x29) {
            variant = Variant.WETRUST;
        } else if (header == 0x7878 && type == MSG_ALARM && buf.getUnsignedShort(buf.readerIndex() + 4) == 0xffff) {
            variant = Variant.JC400;
        } else if (header == 0x7878 && type == MSG_LBS_3 && length == 0x37) {
            variant = Variant.SL4X;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_5 && length == 0x2a) {
            variant = Variant.SL4X;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_STATUS_4 && length == 0x27) {
            variant = Variant.SL4X;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_STATUS_4 && length == 0x29) {
            variant = Variant.SL4X;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_2 && length == 0x2f) {
            variant = Variant.SEEWORLD;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_STATUS_1 && length == 0x26) {
            variant = Variant.SEEWORLD;
        } else if (header == 0x7878 && type == MSG_STATUS_3 && length == 0x0c) {
            variant = Variant.SEEWORLD;
        } else if (header == 0x7878 && type == MSG_STATUS_3 && length == 0x18) {
            variant = Variant.SEEWORLD;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_RFID && length == 0x28) {
            variant = Variant.RFID;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_STATUS_5 && length == 0x40) {
            variant = Variant.LW4G;
        } else if (header == 0x7878 && type == MSG_LOCATION_RFID && length == 0x35) {
            variant = Variant.TRX16I;
        } else if (header == 0x7878 && type == MSG_GPS_LBS_STATUS_1 && length == 0x2D) {
            variant = Variant.TRX16I;
        } else {
            variant = Variant.STANDARD;
        }
    }

}
