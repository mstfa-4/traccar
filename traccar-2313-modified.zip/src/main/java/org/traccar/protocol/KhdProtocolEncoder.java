/*
 * Copyright 2015 - 2026 Anton Tananaev (anton@traccar.org)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package org.traccar.protocol;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import org.traccar.BaseProtocolEncoder;
import org.traccar.Protocol;
import org.traccar.helper.BitUtil;
import org.traccar.helper.CharsetUtil;
import org.traccar.helper.Checksum;
import org.traccar.model.Command;

public class KhdProtocolEncoder extends BaseProtocolEncoder {

    public static final int MSG_ON_DEMAND_TRACK = 0x30;
    public static final int MSG_REBOOT = 0x32;
    public static final int MSG_CUT_OIL = 0x39;
    public static final int MSG_SEND_TEXT = 0x3A;
    public static final int MSG_RESUME_OIL = 0x38;
    public static final int MSG_CHECK_VERSION = 0x3D;
    public static final int MSG_FACTORY_RESET = 0xC3;
    public static final int MSG_SET_OVERSPEED = 0x3F;
    public static final int MSG_DELETE_MILEAGE = 0x66;
    public static final int MSG_PERIODIC_TRACK = 0x7B;

    public KhdProtocolEncoder(Protocol protocol) {
        super(protocol);
    }

    byte[] encodeIdentifier(String uniqueId) {
        int mask = 0b0110;
        if (uniqueId.length() == 11 && uniqueId.startsWith("1")) {
            int prefix = Integer.parseInt(uniqueId.substring(0, 3));
            mask = prefix - 130 - (prefix >= 156 && prefix <= 159 ? 16 : 0);
        }
        uniqueId = "00000000".concat(uniqueId);
        uniqueId = uniqueId.substring(uniqueId.length() - 8);
        byte[] identifier = new byte[4];
        for (int i = 0; i < 4; i++) {
            int value = Integer.parseInt(uniqueId.substring(i * 2, i * 2 + 2));
            identifier[i] = (byte) (value + (BitUtil.check(mask, 3 - i) ? 0x80 : 0));
        }
        return identifier;
    }

    private ByteBuf encodeCommand(int command, String uniqueId, ByteBuf content) {

        ByteBuf buf = Unpooled.buffer();

        buf.writeByte(0x29);
        buf.writeByte(0x29);

        buf.writeByte(command);

        int length = 6;
        if (content != null) {
            length += content.readableBytes();
        }
        buf.writeShort(length);

        buf.writeBytes(encodeIdentifier(uniqueId));

        if (content != null) {
            buf.writeBytes(content);
        }

        buf.writeByte(Checksum.xor(buf.nioBuffer()));
        buf.writeByte(0x0D); // ending

        return buf;
    }

    @Override
    protected Object encodeCommand(Command command) {

        String uniqueId = getUniqueId(command.getDeviceId());

        return switch (command.getType()) {
            case Command.TYPE_CUSTOM -> {
                ByteBuf content = Unpooled.copiedBuffer(
                        command.getString(Command.KEY_DATA), CharsetUtil.GB2312);
                yield encodeCommand(MSG_SEND_TEXT, uniqueId, content);
            }
            case Command.TYPE_ENGINE_STOP -> encodeCommand(MSG_CUT_OIL, uniqueId, null);
            case Command.TYPE_ENGINE_RESUME -> encodeCommand(MSG_RESUME_OIL, uniqueId, null);
            case Command.TYPE_GET_VERSION -> encodeCommand(MSG_CHECK_VERSION, uniqueId, null);
            case Command.TYPE_FACTORY_RESET -> encodeCommand(MSG_FACTORY_RESET, uniqueId, null);
            case Command.TYPE_SET_SPEED_LIMIT -> {
                ByteBuf content = Unpooled.buffer();
                content.writeByte(command.getInteger(Command.KEY_DATA));
                yield encodeCommand(MSG_SET_OVERSPEED, uniqueId, content);
            }
            case Command.TYPE_SET_ODOMETER -> encodeCommand(MSG_DELETE_MILEAGE, uniqueId, null);
            case Command.TYPE_POSITION_SINGLE -> encodeCommand(MSG_ON_DEMAND_TRACK, uniqueId, null);
            case Command.TYPE_POSITION_PERIODIC -> {
                ByteBuf content = Unpooled.buffer();
                content.writeShort(command.getInteger(Command.KEY_FREQUENCY));
                content.writeShort(0xFFFF); // report count
                yield encodeCommand(MSG_PERIODIC_TRACK, uniqueId, content);
            }
            case Command.TYPE_REBOOT_DEVICE -> encodeCommand(MSG_REBOOT, uniqueId, null);
            default -> null;
        };
    }

}
